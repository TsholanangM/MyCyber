export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api',
  aiServiceUrl: 'http://localhost:5000'
};
