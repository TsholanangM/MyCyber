import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./components/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./components/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: '',
    loadComponent: () => import('./components/layout/main-layout/main-layout.component').then(m => m.MainLayoutComponent),
    canActivate: [authGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'incidents',
        loadComponent: () => import('./components/incidents/incident-list/incident-list.component').then(m => m.IncidentListComponent)
      },
      {
        path: 'incidents/create',
        loadComponent: () => import('./components/incidents/incident-form/incident-form.component').then(m => m.IncidentFormComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'incidents/edit/:id',
        loadComponent: () => import('./components/incidents/incident-form/incident-form.component').then(m => m.IncidentFormComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'incidents/:id',
        loadComponent: () => import('./components/incidents/incident-detail/incident-detail.component').then(m => m.IncidentDetailComponent)
      },
      {
        path: 'threats',
        loadComponent: () => import('./components/threats/threat-list/threat-list.component').then(m => m.ThreatListComponent)
      },
      {
        path: 'threats/create',
        loadComponent: () => import('./components/threats/threat-form/threat-form.component').then(m => m.ThreatFormComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'threats/edit/:id',
        loadComponent: () => import('./components/threats/threat-form/threat-form.component').then(m => m.ThreatFormComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'systems',
        loadComponent: () => import('./components/systems/system-list/system-list.component').then(m => m.SystemListComponent)
      },
      {
        path: 'systems/create',
        loadComponent: () => import('./components/systems/system-form/system-form.component').then(m => m.SystemFormComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'systems/edit/:id',
        loadComponent: () => import('./components/systems/system-form/system-form.component').then(m => m.SystemFormComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'users',
        loadComponent: () => import('./components/users/user-list/user-list.component').then(m => m.UserListComponent),
        canActivate: [() => roleGuard(['ADMIN'])]
      },
      {
        path: 'logs',
        loadComponent: () => import('./components/logs/log-list/log-list.component').then(m => m.LogListComponent),
        canActivate: [() => roleGuard(['ADMIN', 'ANALYST'])]
      },
      {
        path: 'profile',
        loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent)
      }
    ]
  },
  {
    path: '**',
    loadComponent: () => import('./components/shared/not-found/not-found.component').then(m => m.NotFoundComponent)
  }
];
