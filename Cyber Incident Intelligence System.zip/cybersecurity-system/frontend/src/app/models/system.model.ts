export enum VulnerabilityLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export enum SystemStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  MAINTENANCE = 'MAINTENANCE',
  COMPROMISED = 'COMPROMISED'
}

export enum SystemType {
  SERVER = 'SERVER',
  WORKSTATION = 'WORKSTATION',
  NETWORK_DEVICE = 'NETWORK_DEVICE',
  APPLICATION = 'APPLICATION',
  DATABASE = 'DATABASE'
}

export interface System {
  id: number;
  systemName: string;
  owner: string;
  description?: string;
  ipAddress?: string;
  vulnerabilityLevel: VulnerabilityLevel;
  systemType: SystemType;
  status: SystemStatus;
  location?: string;
  createdAt?: Date;
  updatedAt?: Date;
}
