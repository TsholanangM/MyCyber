import { Incident } from './incident.model';
import { Threat } from './threat.model';

export interface DashboardStats {
  openIncidents: number;
  criticalIncidents: number;
  activeThreats: number;
  activeSystems: number;
  highRiskSystems: number;
  incidentsToday: number;
  logs24h: number;
  incidentsBySeverity: { [key: string]: number };
  incidentsByStatus: { [key: string]: number };
  systemsByVulnerability: { [key: string]: number };
  threatsByRiskLevel: { [key: string]: number };
  recentIncidents: Incident[];
  recentThreats: Threat[];
  recentActivities: ActivityLog[];
}

export interface ActivityLog {
  id: number;
  userId?: number;
  userName?: string;
  action: string;
  entityType: string;
  entityId?: number;
  description?: string;
  ipAddress?: string;
  severity: string;
  timestamp: Date;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label?: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
  }[];
}
