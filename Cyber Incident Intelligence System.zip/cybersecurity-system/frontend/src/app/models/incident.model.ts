export enum IncidentSeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export enum IncidentStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  PENDING = 'PENDING',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED'
}

export interface Incident {
  id: number;
  incidentNumber: string;
  title: string;
  description: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  incidentType?: string;
  attackTypeId?: number;
  attackTypeName?: string;
  affectedSystemId?: number;
  affectedSystemName?: string;
  reportedBy: number;
  reportedByName?: string;
  assignedTo?: number;
  assignedToName?: string;
  threatId?: number;
  rootCause?: string;
  impactAssessment?: string;
  resolutionNotes?: string;
  detectedAt: Date;
  reportedAt?: Date;
  resolvedAt?: Date;
  closedAt?: Date;
  slaBreach?: boolean;
  estimatedLoss?: number;
  createdAt?: Date;
  updatedAt?: Date;
}
