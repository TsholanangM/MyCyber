export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export enum ThreatStatus {
  ACTIVE = 'ACTIVE',
  INVESTIGATING = 'INVESTIGATING',
  CONTAINED = 'CONTAINED',
  RESOLVED = 'RESOLVED',
  FALSE_POSITIVE = 'FALSE_POSITIVE'
}

export interface Threat {
  id: number;
  threatName: string;
  type: string;
  riskLevel: RiskLevel;
  description?: string;
  attackTypeId?: number;
  attackTypeName?: string;
  affectedSystemId?: number;
  affectedSystemName?: string;
  sourceIp?: string;
  targetIp?: string;
  indicatorsOfCompromise?: string;
  mitigationStrategy?: string;
  detectedAt?: Date;
  resolvedAt?: Date;
  status: ThreatStatus;
  detectedBy?: number;
  detectedByName?: string;
  createdAt?: Date;
  updatedAt?: Date;
}
