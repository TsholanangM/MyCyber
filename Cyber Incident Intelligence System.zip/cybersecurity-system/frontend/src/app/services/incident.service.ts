import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Incident, IncidentSeverity, IncidentStatus } from '../models/incident.model';

export interface PageResponse<T> {
  content: T[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class IncidentService {
  private readonly API_URL = `${environment.apiUrl}/incidents`;

  constructor(private http: HttpClient) {}

  getAllIncidents(
    page: number = 0,
    size: number = 10,
    sortBy: string = 'detectedAt',
    direction: string = 'desc'
  ): Observable<{ success: boolean; message: string; data: PageResponse<Incident> }> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sortBy', sortBy)
      .set('direction', direction);

    return this.http.get<{ success: boolean; message: string; data: PageResponse<Incident> }>(
      this.API_URL,
      { params }
    );
  }

  getIncidentById(id: number): Observable<{ success: boolean; message: string; data: Incident }> {
    return this.http.get<{ success: boolean; message: string; data: Incident }>(
      `${this.API_URL}/${id}`
    );
  }

  getIncidentByNumber(incidentNumber: string): Observable<{ success: boolean; message: string; data: Incident }> {
    return this.http.get<{ success: boolean; message: string; data: Incident }>(
      `${this.API_URL}/number/${incidentNumber}`
    );
  }

  createIncident(incident: Partial<Incident>): Observable<{ success: boolean; message: string; data: Incident }> {
    return this.http.post<{ success: boolean; message: string; data: Incident }>(
      this.API_URL,
      incident
    );
  }

  updateIncident(id: number, incident: Partial<Incident>): Observable<{ success: boolean; message: string; data: Incident }> {
    return this.http.put<{ success: boolean; message: string; data: Incident }>(
      `${this.API_URL}/${id}`,
      incident
    );
  }

  updateIncidentStatus(id: number, status: IncidentStatus): Observable<{ success: boolean; message: string; data: Incident }> {
    return this.http.patch<{ success: boolean; message: string; data: Incident }>(
      `${this.API_URL}/${id}/status`,
      null,
      { params: { status } }
    );
  }

  deleteIncident(id: number): Observable<{ success: boolean; message: string; data: null }> {
    return this.http.delete<{ success: boolean; message: string; data: null }>(
      `${this.API_URL}/${id}`
    );
  }

  searchIncidents(
    status?: IncidentStatus,
    severity?: IncidentSeverity,
    assignedTo?: number,
    search?: string,
    page: number = 0,
    size: number = 10
  ): Observable<{ success: boolean; message: string; data: PageResponse<Incident> }> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    if (status) params = params.set('status', status);
    if (severity) params = params.set('severity', severity);
    if (assignedTo) params = params.set('assignedTo', assignedTo.toString());
    if (search) params = params.set('search', search);

    return this.http.get<{ success: boolean; message: string; data: PageResponse<Incident> }>(
      `${this.API_URL}/search`,
      { params }
    );
  }

  getRecentIncidents(limit: number = 5): Observable<{ success: boolean; message: string; data: Incident[] }> {
    return this.http.get<{ success: boolean; message: string; data: Incident[] }>(
      `${this.API_URL}/recent`,
      { params: { limit: limit.toString() } }
    );
  }

  getStatsBySeverity(): Observable<{ success: boolean; message: string; data: { [key: string]: number } }> {
    return this.http.get<{ success: boolean; message: string; data: { [key: string]: number } }>(
      `${this.API_URL}/stats/by-severity`
    );
  }

  getStatsByStatus(): Observable<{ success: boolean; message: string; data: { [key: string]: number } }> {
    return this.http.get<{ success: boolean; message: string; data: { [key: string]: number } }>(
      `${this.API_URL}/stats/by-status`
    );
  }
}
