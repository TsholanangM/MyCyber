import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { DashboardStats } from '../models/dashboard.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private readonly API_URL = `${environment.apiUrl}/dashboard`;

  constructor(private http: HttpClient) {}

  getDashboardStats(): Observable<{ success: boolean; message: string; data: DashboardStats }> {
    return this.http.get<{ success: boolean; message: string; data: DashboardStats }>(
      `${this.API_URL}/stats`
    );
  }

  getIncidentTrends(days: number = 30): Observable<{ success: boolean; message: string; data: any }> {
    const params = new HttpParams().set('days', days.toString());
    return this.http.get<{ success: boolean; message: string; data: any }>(
      `${this.API_URL}/incident-trends`,
      { params }
    );
  }

  getThreatIntelligence(): Observable<{ success: boolean; message: string; data: any }> {
    return this.http.get<{ success: boolean; message: string; data: any }>(
      `${this.API_URL}/threat-intelligence`
    );
  }

  getSystemHealth(): Observable<{ success: boolean; message: string; data: any }> {
    return this.http.get<{ success: boolean; message: string; data: any }>(
      `${this.API_URL}/system-health`
    );
  }
}
