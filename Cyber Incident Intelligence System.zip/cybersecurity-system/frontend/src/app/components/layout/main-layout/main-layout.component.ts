import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { User, UserRole } from '../../../models/user.model';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="layout-wrapper">
      <!-- Sidebar -->
      <aside class="sidebar" [class.collapsed]="sidebarCollapsed">
        <div class="sidebar-header">
          <div class="logo">
            <i class="fas fa-shield-alt"></i>
            <span *ngIf="!sidebarCollapsed">CyberSec</span>
          </div>
          <button class="toggle-btn" (click)="toggleSidebar()">
            <i class="fas" [class.fa-chevron-left]="!sidebarCollapsed" [class.fa-chevron-right]="sidebarCollapsed"></i>
          </button>
        </div>
        
        <nav class="sidebar-nav">
          <ul>
            <li>
              <a routerLink="/dashboard" routerLinkActive="active">
                <i class="fas fa-tachometer-alt"></i>
                <span *ngIf="!sidebarCollapsed">Dashboard</span>
              </a>
            </li>
            <li>
              <a routerLink="/incidents" routerLinkActive="active">
                <i class="fas fa-exclamation-triangle"></i>
                <span *ngIf="!sidebarCollapsed">Incidents</span>
              </a>
            </li>
            <li>
              <a routerLink="/threats" routerLinkActive="active">
                <i class="fas fa-virus"></i>
                <span *ngIf="!sidebarCollapsed">Threats</span>
              </a>
            </li>
            <li>
              <a routerLink="/systems" routerLinkActive="active">
                <i class="fas fa-server"></i>
                <span *ngIf="!sidebarCollapsed">Systems</span>
              </a>
            </li>
            <li *ngIf="isAdmin()">
              <a routerLink="/users" routerLinkActive="active">
                <i class="fas fa-users"></i>
                <span *ngIf="!sidebarCollapsed">Users</span>
              </a>
            </li>
            <li *ngIf="isAdminOrAnalyst()">
              <a routerLink="/logs" routerLinkActive="active">
                <i class="fas fa-history"></i>
                <span *ngIf="!sidebarCollapsed">Activity Logs</span>
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      <!-- Main Content -->
      <div class="main-wrapper" [class.expanded]="sidebarCollapsed">
        <!-- Header -->
        <header class="header">
          <div class="header-left">
            <h1 class="page-title">{{ getPageTitle() }}</h1>
          </div>
          <div class="header-right">
            <div class="user-menu">
              <div class="user-info" (click)="toggleUserMenu()">
                <div class="user-avatar">
                  <i class="fas fa-user-circle"></i>
                </div>
                <span class="user-name">{{ currentUser?.name }}</span>
                <i class="fas fa-chevron-down"></i>
              </div>
              <div class="dropdown-menu" *ngIf="userMenuOpen">
                <a routerLink="/profile" class="dropdown-item">
                  <i class="fas fa-user"></i> Profile
                </a>
                <div class="dropdown-divider"></div>
                <a (click)="logout()" class="dropdown-item">
                  <i class="fas fa-sign-out-alt"></i> Logout
                </a>
              </div>
            </div>
          </div>
        </header>

        <!-- Content -->
        <main class="content">
          <router-outlet></router-outlet>
        </main>
      </div>
    </div>
  `,
  styles: [`
    .layout-wrapper {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      position: fixed;
      left: 0;
      top: 0;
      width: var(--sidebar-width);
      height: 100vh;
      background: var(--primary-color);
      color: white;
      transition: width 0.3s ease;
      z-index: 1000;
      overflow-y: auto;
    }

    .sidebar.collapsed {
      width: var(--sidebar-collapsed-width);
    }

    .sidebar-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      font-size: 1.25rem;
      font-weight: 600;
    }

    .logo i {
      font-size: 1.5rem;
      color: var(--secondary-light);
    }

    .toggle-btn {
      background: transparent;
      border: none;
      color: white;
      cursor: pointer;
      padding: 0.25rem;
    }

    .sidebar-nav {
      padding: 1rem 0;
    }

    .sidebar-nav ul {
      list-style: none;
      padding: 0;
    }

    .sidebar-nav li {
      margin: 0.25rem 0;
    }

    .sidebar-nav a {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.75rem 1rem;
      color: rgba(255, 255, 255, 0.8);
      text-decoration: none;
      transition: all 0.2s ease;
    }

    .sidebar-nav a:hover,
    .sidebar-nav a.active {
      background: rgba(255, 255, 255, 0.1);
      color: white;
    }

    .sidebar-nav i {
      width: 20px;
      text-align: center;
    }

    .main-wrapper {
      flex: 1;
      margin-left: var(--sidebar-width);
      transition: margin-left 0.3s ease;
    }

    .main-wrapper.expanded {
      margin-left: var(--sidebar-collapsed-width);
    }

    .header {
      position: sticky;
      top: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 1.5rem;
      height: var(--header-height);
      background: white;
      box-shadow: var(--box-shadow);
      z-index: 100;
    }

    .page-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--gray-800);
    }

    .header-right {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .user-menu {
      position: relative;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem;
      cursor: pointer;
      border-radius: var(--border-radius);
      transition: background 0.2s ease;
    }

    .user-info:hover {
      background: var(--gray-100);
    }

    .user-avatar {
      font-size: 1.5rem;
      color: var(--primary-color);
    }

    .user-name {
      font-weight: 500;
      color: var(--gray-700);
    }

    .dropdown-menu {
      position: absolute;
      top: 100%;
      right: 0;
      min-width: 180px;
      background: white;
      border-radius: var(--border-radius);
      box-shadow: var(--box-shadow-lg);
      margin-top: 0.5rem;
      overflow: hidden;
    }

    .dropdown-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1rem;
      color: var(--gray-700);
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .dropdown-item:hover {
      background: var(--gray-100);
    }

    .dropdown-divider {
      height: 1px;
      background: var(--gray-200);
      margin: 0.5rem 0;
    }

    .content {
      padding: 1.5rem;
      min-height: calc(100vh - var(--header-height));
    }

    @media (max-width: 991.98px) {
      .sidebar {
        transform: translateX(-100%);
      }

      .sidebar.open {
        transform: translateX(0);
      }

      .main-wrapper {
        margin-left: 0;
      }

      .main-wrapper.expanded {
        margin-left: 0;
      }
    }
  `]
})
export class MainLayoutComponent implements OnInit {
  sidebarCollapsed = false;
  userMenuOpen = false;
  currentUser: User | null = null;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  toggleUserMenu(): void {
    this.userMenuOpen = !this.userMenuOpen;
  }

  logout(): void {
    this.authService.logout();
  }

  isAdmin(): boolean {
    return this.authService.isAdmin();
  }

  isAdminOrAnalyst(): boolean {
    return this.authService.hasAnyRole([UserRole.ADMIN, UserRole.ANALYST]);
  }

  getPageTitle(): string {
    // This would typically be set based on the current route
    return 'Dashboard';
  }
}
