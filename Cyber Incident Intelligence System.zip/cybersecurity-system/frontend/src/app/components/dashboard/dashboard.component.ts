import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration, ChartData } from 'chart.js';
import { DashboardService } from '../../services/dashboard.service';
import { DashboardStats, ChartData as DashboardChartData } from '../../models/dashboard.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, BaseChartDirective],
  template: `
    <div class="dashboard">
      <!-- Stats Cards -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon primary">
            <i class="fas fa-exclamation-circle"></i>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats?.openIncidents || 0 }}</div>
            <div class="stat-label">Open Incidents</div>
          </div>
        </div>
        
        <div class="stat-card">
          <div class="stat-icon danger">
            <i class="fas fa-radiation"></i>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats?.criticalIncidents || 0 }}</div>
            <div class="stat-label">Critical Incidents</div>
          </div>
        </div>
        
        <div class="stat-card">
          <div class="stat-icon warning">
            <i class="fas fa-virus"></i>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats?.activeThreats || 0 }}</div>
            <div class="stat-label">Active Threats</div>
          </div>
        </div>
        
        <div class="stat-card">
          <div class="stat-icon success">
            <i class="fas fa-server"></i>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats?.activeSystems || 0 }}</div>
            <div class="stat-label">Active Systems</div>
          </div>
        </div>
      </div>

      <!-- Charts Row -->
      <div class="charts-grid">
        <div class="card chart-card">
          <div class="card-header">
            <h3>Incidents by Severity</h3>
          </div>
          <div class="card-body">
            <canvas baseChart
              [data]="severityChartData"
              [options]="pieChartOptions"
              [type]="'doughnut'">
            </canvas>
          </div>
        </div>
        
        <div class="card chart-card">
          <div class="card-header">
            <h3>Systems by Vulnerability</h3>
          </div>
          <div class="card-body">
            <canvas baseChart
              [data]="vulnerabilityChartData"
              [options]="pieChartOptions"
              [type]="'pie'">
            </canvas>
          </div>
        </div>
      </div>

      <!-- Recent Activity Row -->
      <div class="activity-grid">
        <div class="card">
          <div class="card-header">
            <h3>Recent Incidents</h3>
            <a routerLink="/incidents" class="btn btn-sm btn-primary">View All</a>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Severity</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let incident of stats?.recentIncidents">
                    <td>{{ incident.incidentNumber }}</td>
                    <td>{{ incident.title }}</td>
                    <td>
                      <span class="badge" [ngClass]="'badge-' + incident.severity.toLowerCase()">
                        {{ incident.severity }}
                      </span>
                    </td>
                    <td>
                      <span class="badge" [ngClass]="'badge-' + incident.status.toLowerCase().replace('_', '-')">
                        {{ incident.status }}
                      </span>
                    </td>
                    <td>{{ incident.detectedAt | date:'short' }}</td>
                  </tr>
                  <tr *ngIf="!stats?.recentIncidents?.length">
                    <td colspan="5" class="text-center">No recent incidents</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        <div class="card">
          <div class="card-header">
            <h3>Recent Threats</h3>
            <a routerLink="/threats" class="btn btn-sm btn-primary">View All</a>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Risk Level</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let threat of stats?.recentThreats">
                    <td>{{ threat.threatName }}</td>
                    <td>{{ threat.type }}</td>
                    <td>
                      <span class="badge" [ngClass]="'badge-' + threat.riskLevel.toLowerCase()">
                        {{ threat.riskLevel }}
                      </span>
                    </td>
                    <td>
                      <span class="badge" [ngClass]="'badge-' + threat.status.toLowerCase().replace('_', '-')">
                        {{ threat.status }}
                      </span>
                    </td>
                  </tr>
                  <tr *ngIf="!stats?.recentThreats?.length">
                    <td colspan="4" class="text-center">No recent threats</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Activity Logs -->
      <div class="card">
        <div class="card-header">
          <h3>Recent Activity</h3>
        </div>
        <div class="card-body">
          <div class="activity-list">
            <div class="activity-item" *ngFor="let activity of stats?.recentActivities">
              <div class="activity-icon" [ngClass]="getActivityIconClass(activity.severity)">
                <i class="fas" [class]="getActivityIcon(activity.action)"></i>
              </div>
              <div class="activity-content">
                <div class="activity-title">{{ activity.description }}</div>
                <div class="activity-meta">
                  <span>{{ activity.userName || 'System' }}</span>
                  <span>•</span>
                  <span>{{ activity.timestamp | date:'medium' }}</span>
                </div>
              </div>
            </div>
            <div *ngIf="!stats?.recentActivities?.length" class="text-center p-3">
              No recent activity
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 1rem;
    }

    .stat-card {
      display: flex;
      align-items: center;
      padding: 1.25rem;
      background: white;
      border-radius: var(--border-radius);
      box-shadow: var(--box-shadow);
    }

    .stat-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      margin-right: 1rem;
      font-size: 1.25rem;
    }

    .stat-icon.primary {
      background-color: rgba(26, 35, 126, 0.1);
      color: var(--primary-color);
    }

    .stat-icon.danger {
      background-color: rgba(211, 47, 47, 0.1);
      color: var(--secondary-color);
    }

    .stat-icon.warning {
      background-color: rgba(245, 124, 0, 0.1);
      color: var(--warning-color);
    }

    .stat-icon.success {
      background-color: rgba(56, 142, 60, 0.1);
      color: var(--success-color);
    }

    .stat-value {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--gray-900);
    }

    .stat-label {
      font-size: 0.875rem;
      color: var(--gray-600);
    }

    .charts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1rem;
    }

    .chart-card {
      min-height: 350px;
    }

    .chart-card .card-body {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .activity-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
      gap: 1rem;
    }

    .card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .card-header h3 {
      font-size: 1.125rem;
      margin: 0;
    }

    .table-responsive {
      overflow-x: auto;
    }

    .activity-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .activity-item {
      display: flex;
      align-items: flex-start;
      gap: 1rem;
      padding: 0.75rem;
      border-radius: var(--border-radius);
      background: var(--gray-50);
    }

    .activity-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .activity-icon.info {
      background: rgba(25, 118, 210, 0.1);
      color: var(--info-color);
    }

    .activity-icon.warning {
      background: rgba(245, 124, 0, 0.1);
      color: var(--warning-color);
    }

    .activity-icon.error {
      background: rgba(211, 47, 47, 0.1);
      color: var(--secondary-color);
    }

    .activity-icon.critical {
      background: rgba(114, 28, 36, 0.1);
      color: #721c24;
    }

    .activity-content {
      flex: 1;
    }

    .activity-title {
      font-size: 0.875rem;
      font-weight: 500;
      color: var(--gray-800);
    }

    .activity-meta {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-top: 0.25rem;
      font-size: 0.75rem;
      color: var(--gray-600);
    }

    @media (max-width: 767.98px) {
      .activity-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class DashboardComponent implements OnInit {
  stats: DashboardStats | null = null;
  loading = true;

  // Chart data
  severityChartData: ChartData<'doughnut'> = {
    labels: [],
    datasets: [{ data: [], backgroundColor: [] }]
  };

  vulnerabilityChartData: ChartData<'pie'> = {
    labels: [],
    datasets: [{ data: [], backgroundColor: [] }]
  };

  pieChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  };

  constructor(private dashboardService: DashboardService) {}

  ngOnInit(): void {
    this.loadDashboardStats();
  }

  loadDashboardStats(): void {
    this.dashboardService.getDashboardStats().subscribe({
      next: (response) => {
        if (response.success) {
          this.stats = response.data;
          this.updateCharts();
        }
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  updateCharts(): void {
    if (this.stats) {
      // Severity chart
      const severityLabels = Object.keys(this.stats.incidentsBySeverity);
      const severityData = Object.values(this.stats.incidentsBySeverity);
      this.severityChartData = {
        labels: severityLabels,
        datasets: [{
          data: severityData,
          backgroundColor: ['#388e3c', '#f57c00', '#d32f2f', '#721c24']
        }]
      };

      // Vulnerability chart
      const vulnLabels = Object.keys(this.stats.systemsByVulnerability);
      const vulnData = Object.values(this.stats.systemsByVulnerability);
      this.vulnerabilityChartData = {
        labels: vulnLabels,
        datasets: [{
          data: vulnData,
          backgroundColor: ['#388e3c', '#f57c00', '#d32f2f', '#721c24']
        }]
      };
    }
  }

  getActivityIcon(action: string): string {
    if (action.includes('LOGIN')) return 'fa-sign-in-alt';
    if (action.includes('CREATE')) return 'fa-plus';
    if (action.includes('UPDATE')) return 'fa-edit';
    if (action.includes('DELETE')) return 'fa-trash';
    if (action.includes('STATUS')) return 'fa-exchange-alt';
    return 'fa-info-circle';
  }

  getActivityIconClass(severity: string): string {
    switch (severity) {
      case 'CRITICAL': return 'critical';
      case 'ERROR': return 'error';
      case 'WARNING': return 'warning';
      default: return 'info';
    }
  }
}
