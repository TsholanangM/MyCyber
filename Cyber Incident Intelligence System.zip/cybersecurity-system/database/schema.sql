-- ============================================================
-- CYBERSECURITY INCIDENT INTELLIGENCE SYSTEM
-- MySQL Database Schema
-- Fully Normalized with Proper Constraints and Indexing
-- ============================================================

-- Drop database if exists and create new
DROP DATABASE IF EXISTS cybersecurity_db;
CREATE DATABASE cybersecurity_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cybersecurity_db;

-- ============================================================
-- 1. USERS TABLE
-- Stores system users with role-based access control
-- ============================================================
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('ADMIN', 'ANALYST', 'USER') NOT NULL DEFAULT 'USER',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_role (role),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. ATTACK TYPES TABLE
-- Reference table for different types of cyber attacks
-- ============================================================
CREATE TABLE attack_types (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    severity_weight DECIMAL(3,2) DEFAULT 1.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. SYSTEMS TABLE
-- Tracks monitored systems and their vulnerability levels
-- ============================================================
CREATE TABLE systems (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    system_name VARCHAR(150) NOT NULL,
    owner VARCHAR(100) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    vulnerability_level ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') DEFAULT 'LOW',
    system_type ENUM('SERVER', 'WORKSTATION', 'NETWORK_DEVICE', 'APPLICATION', 'DATABASE') NOT NULL,
    status ENUM('ACTIVE', 'INACTIVE', 'MAINTENANCE', 'COMPROMISED') DEFAULT 'ACTIVE',
    location VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_system_name (system_name),
    INDEX idx_vulnerability (vulnerability_level),
    INDEX idx_status (status),
    INDEX idx_owner (owner)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. THREATS TABLE
-- Stores identified threats and their risk assessments
-- ============================================================
CREATE TABLE threats (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    threat_name VARCHAR(150) NOT NULL,
    type VARCHAR(100) NOT NULL,
    risk_level ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL,
    description TEXT,
    attack_type_id BIGINT UNSIGNED,
    affected_system_id BIGINT UNSIGNED,
    source_ip VARCHAR(45),
    target_ip VARCHAR(45),
    indicators_of_compromise TEXT,
    mitigation_strategy TEXT,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    status ENUM('ACTIVE', 'INVESTIGATING', 'CONTAINED', 'RESOLVED', 'FALSE_POSITIVE') DEFAULT 'ACTIVE',
    detected_by BIGINT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_threat_attack_type 
        FOREIGN KEY (attack_type_id) REFERENCES attack_types(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_threat_system 
        FOREIGN KEY (affected_system_id) REFERENCES systems(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_threat_detected_by 
        FOREIGN KEY (detected_by) REFERENCES users(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX idx_risk_level (risk_level),
    INDEX idx_status (status),
    INDEX idx_detected_at (detected_at),
    INDEX idx_attack_type (attack_type_id),
    INDEX idx_affected_system (affected_system_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. INCIDENTS TABLE
-- Main table for cybersecurity incidents
-- ============================================================
CREATE TABLE incidents (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    incident_number VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    severity ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL,
    status ENUM('OPEN', 'IN_PROGRESS', 'PENDING', 'RESOLVED', 'CLOSED') DEFAULT 'OPEN',
    incident_type VARCHAR(100),
    attack_type_id BIGINT UNSIGNED,
    affected_system_id BIGINT UNSIGNED,
    reported_by BIGINT UNSIGNED NOT NULL,
    assigned_to BIGINT UNSIGNED,
    threat_id BIGINT UNSIGNED,
    root_cause TEXT,
    impact_assessment TEXT,
    resolution_notes TEXT,
    detected_at TIMESTAMP NOT NULL,
    reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    closed_at TIMESTAMP NULL,
    sla_breach BOOLEAN DEFAULT FALSE,
    estimated_loss DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_incident_attack_type 
        FOREIGN KEY (attack_type_id) REFERENCES attack_types(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_incident_system 
        FOREIGN KEY (affected_system_id) REFERENCES systems(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_incident_reported_by 
        FOREIGN KEY (reported_by) REFERENCES users(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_incident_assigned_to 
        FOREIGN KEY (assigned_to) REFERENCES users(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_incident_threat 
        FOREIGN KEY (threat_id) REFERENCES threats(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX idx_incident_number (incident_number),
    INDEX idx_severity (severity),
    INDEX idx_status (status),
    INDEX idx_detected_at (detected_at),
    INDEX idx_reported_at (reported_at),
    INDEX idx_assigned_to (assigned_to),
    INDEX idx_attack_type (attack_type_id),
    INDEX idx_composite_status_severity (status, severity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. INCIDENT ACTIVITIES TABLE
-- Tracks all activities/updates related to an incident
-- ============================================================
CREATE TABLE incident_activities (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    incident_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    activity_type ENUM('CREATED', 'UPDATED', 'ASSIGNED', 'STATUS_CHANGED', 'NOTE_ADDED', 'FILE_ATTACHED', 'ESCALATED', 'RESOLVED', 'CLOSED') NOT NULL,
    description TEXT NOT NULL,
    old_value VARCHAR(255),
    new_value VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_activity_incident 
        FOREIGN KEY (incident_id) REFERENCES incidents(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_activity_user 
        FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE RESTRICT ON UPDATE CASCADE,
    
    INDEX idx_incident_id (incident_id),
    INDEX idx_activity_type (activity_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 7. SYSTEM LOGS TABLE
-- General system and user activity logging
-- ============================================================
CREATE TABLE logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED,
    action VARCHAR(100) NOT NULL,
    entity_type ENUM('USER', 'INCIDENT', 'THREAT', 'SYSTEM', 'ATTACK_TYPE', 'SETTINGS') NOT NULL,
    entity_id BIGINT UNSIGNED,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    severity ENUM('INFO', 'WARNING', 'ERROR', 'CRITICAL') DEFAULT 'INFO',
    metadata JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_log_user 
        FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE SET NULL ON UPDATE CASCADE,
    
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_timestamp (timestamp),
    INDEX idx_severity (severity),
    INDEX idx_composite_user_timestamp (user_id, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 8. AI PREDICTIONS TABLE
-- Stores AI model predictions for threat analysis
-- ============================================================
CREATE TABLE ai_predictions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    prediction_type ENUM('ATTACK_LIKELIHOOD', 'SEVERITY_CLASSIFICATION', 'RISK_SCORE', 'ANOMALY_DETECTION') NOT NULL,
    entity_type ENUM('SYSTEM', 'INCIDENT', 'THREAT') NOT NULL,
    entity_id BIGINT UNSIGNED NOT NULL,
    prediction_value VARCHAR(100) NOT NULL,
    confidence_score DECIMAL(5,4) NOT NULL,
    model_version VARCHAR(50),
    features_used JSON,
    prediction_data JSON,
    validated BOOLEAN DEFAULT NULL,
    validation_result BOOLEAN DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_prediction_type (prediction_type),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created_at (created_at),
    INDEX idx_confidence (confidence_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 9. NOTIFICATIONS TABLE
-- User notifications for incidents and threats
-- ============================================================
CREATE TABLE notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('INCIDENT_ASSIGNED', 'THREAT_DETECTED', 'SYSTEM_ALERT', 'ESCALATION', 'GENERAL') NOT NULL,
    related_entity_type ENUM('INCIDENT', 'THREAT', 'SYSTEM') NULL,
    related_entity_id BIGINT UNSIGNED NULL,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_notification_user 
        FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 10. SYSTEM METRICS TABLE
-- Historical system metrics for AI training
-- ============================================================
CREATE TABLE system_metrics (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    system_id BIGINT UNSIGNED NOT NULL,
    metric_type ENUM('CPU_USAGE', 'MEMORY_USAGE', 'NETWORK_TRAFFIC', 'DISK_USAGE', 'FAILED_LOGINS', 'PORT_SCANS') NOT NULL,
    metric_value DECIMAL(10,2) NOT NULL,
    unit VARCHAR(20),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_metric_system 
        FOREIGN KEY (system_id) REFERENCES systems(id) 
        ON DELETE CASCADE ON UPDATE CASCADE,
    
    INDEX idx_system_id (system_id),
    INDEX idx_metric_type (metric_type),
    INDEX idx_recorded_at (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- INSERT SAMPLE DATA
-- ============================================================

-- Sample Attack Types
INSERT INTO attack_types (name, description, severity_weight) VALUES
('Malware', 'Malicious software designed to harm or exploit systems', 1.50),
('Phishing', 'Social engineering attack to steal credentials', 1.20),
('DDoS', 'Distributed Denial of Service attack', 1.80),
('SQL Injection', 'Database injection attack', 1.60),
('Ransomware', 'Malware that encrypts data for ransom', 2.00),
('Man-in-the-Middle', 'Intercepting communication between parties', 1.70),
('Zero-Day Exploit', 'Exploiting unknown vulnerabilities', 2.00),
('Insider Threat', 'Malicious actions by internal users', 1.50),
('Brute Force', 'Password cracking through repeated attempts', 1.30),
('Cross-Site Scripting', 'Injecting malicious scripts into web pages', 1.40);

-- Sample Users (password: 'password123' encrypted with BCrypt)
INSERT INTO users (name, email, password, role, is_active) VALUES
('Admin User', 'admin@cybersec.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ADMIN', TRUE),
('Security Analyst', 'analyst@cybersec.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ANALYST', TRUE),
('John Operator', 'operator@cybersec.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'USER', TRUE);

-- Sample Systems
INSERT INTO systems (system_name, owner, description, ip_address, vulnerability_level, system_type, status, location) VALUES
('Web Server 01', 'Infrastructure Team', 'Primary web server hosting public applications', '192.168.1.10', 'MEDIUM', 'SERVER', 'ACTIVE', 'Data Center A'),
('Database Server', 'DBA Team', 'Main database server with customer data', '192.168.1.20', 'HIGH', 'DATABASE', 'ACTIVE', 'Data Center A'),
('Mail Server', 'Infrastructure Team', 'Corporate email server', '192.168.1.30', 'LOW', 'SERVER', 'ACTIVE', 'Data Center B'),
('Firewall', 'Network Team', 'Main perimeter firewall', '192.168.1.1', 'MEDIUM', 'NETWORK_DEVICE', 'ACTIVE', 'Data Center A'),
('HR Workstation', 'HR Department', 'Workstation for HR staff', '192.168.2.50', 'LOW', 'WORKSTATION', 'ACTIVE', 'Office Floor 2');

-- Sample Threats
INSERT INTO threats (threat_name, type, risk_level, description, attack_type_id, affected_system_id, source_ip, indicators_of_compromise, mitigation_strategy, status, detected_by) VALUES
('Suspicious Port Scan', 'Reconnaissance', 'MEDIUM', 'Multiple port scans detected from external IP', 9, 4, '203.0.113.45', 'High frequency connection attempts on ports 22, 80, 443', 'Block source IP, review firewall rules', 'CONTAINED', 2),
('Phishing Campaign', 'Social Engineering', 'HIGH', 'Mass phishing emails targeting employees', 2, NULL, '198.51.100.20', 'Emails from suspicious domain with malicious attachments', 'Email filter update, user awareness training', 'INVESTIGATING', 2),
('Malware Detection', 'Malware', 'CRITICAL', 'Trojan detected on workstation', 1, 5, '192.168.2.50', 'File hash: a1b2c3d4, Registry modification detected', 'Isolate system, run antivirus, forensic analysis', 'ACTIVE', 2);

-- Sample Incidents
INSERT INTO incidents (incident_number, title, description, severity, status, incident_type, attack_type_id, affected_system_id, reported_by, assigned_to, threat_id, root_cause, impact_assessment, detected_at) VALUES
('INC-2024-0001', 'Phishing Attack on Finance Department', 'Multiple employees received sophisticated phishing emails attempting to steal credentials', 'HIGH', 'IN_PROGRESS', 'Email Security', 2, NULL, 2, 2, 2, 'Lack of email filtering rules', 'Potential credential compromise, financial data at risk', '2024-01-15 09:30:00'),
('INC-2024-0002', 'Database Server Slow Performance', 'Unusual performance degradation detected on main database server', 'MEDIUM', 'OPEN', 'Performance', NULL, 2, 3, NULL, NULL, NULL, 'Service disruption affecting customer transactions', '2024-01-16 14:20:00'),
('INC-2024-0003', 'Ransomware Infection', 'Workstation infected with ransomware, files encrypted', 'CRITICAL', 'IN_PROGRESS', 'Malware', 5, 5, 2, 1, 3, 'User clicked malicious link', 'Data loss on workstation, potential lateral movement risk', '2024-01-17 11:00:00');

-- Sample Logs
INSERT INTO logs (user_id, action, entity_type, entity_id, description, ip_address, severity) VALUES
(1, 'LOGIN', 'USER', 1, 'User logged in successfully', '10.0.0.1', 'INFO'),
(2, 'INCIDENT_CREATED', 'INCIDENT', 1, 'Created incident INC-2024-0001', '10.0.0.2', 'INFO'),
(2, 'THREAT_DETECTED', 'THREAT', 1, 'New threat detected: Suspicious Port Scan', '10.0.0.2', 'WARNING'),
(1, 'USER_CREATED', 'USER', 3, 'Created new user: John Operator', '10.0.0.1', 'INFO');

-- ============================================================
-- VIEWS FOR COMMON QUERIES
-- ============================================================

-- View: Incident Summary
CREATE VIEW incident_summary AS
SELECT 
    i.id,
    i.incident_number,
    i.title,
    i.severity,
    i.status,
    i.detected_at,
    i.resolved_at,
    u1.name as reported_by_name,
    u2.name as assigned_to_name,
    at.name as attack_type_name,
    s.system_name as affected_system_name
FROM incidents i
LEFT JOIN users u1 ON i.reported_by = u1.id
LEFT JOIN users u2 ON i.assigned_to = u2.id
LEFT JOIN attack_types at ON i.attack_type_id = at.id
LEFT JOIN systems s ON i.affected_system_id = s.id;

-- View: Threat Summary
CREATE VIEW threat_summary AS
SELECT 
    t.id,
    t.threat_name,
    t.risk_level,
    t.status,
    t.detected_at,
    at.name as attack_type_name,
    s.system_name as affected_system_name,
    u.name as detected_by_name
FROM threats t
LEFT JOIN attack_types at ON t.attack_type_id = at.id
LEFT JOIN systems s ON t.affected_system_id = s.id
LEFT JOIN users u ON t.detected_by = u.id;

-- View: User Activity Summary
CREATE VIEW user_activity_summary AS
SELECT 
    u.id,
    u.name,
    u.email,
    u.role,
    u.last_login,
    COUNT(DISTINCT i.id) as incidents_reported,
    COUNT(DISTINCT CASE WHEN i.assigned_to = u.id THEN i.id END) as incidents_assigned,
    COUNT(DISTINCT l.id) as total_actions
FROM users u
LEFT JOIN incidents i ON u.id = i.reported_by
LEFT JOIN logs l ON u.id = l.user_id
GROUP BY u.id, u.name, u.email, u.role, u.last_login;

-- ============================================================
-- STORED PROCEDURES
-- ============================================================

DELIMITER //

-- Procedure: Get Dashboard Statistics
CREATE PROCEDURE GetDashboardStatistics()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM incidents WHERE status IN ('OPEN', 'IN_PROGRESS')) as open_incidents,
        (SELECT COUNT(*) FROM incidents WHERE severity = 'CRITICAL' AND status IN ('OPEN', 'IN_PROGRESS')) as critical_incidents,
        (SELECT COUNT(*) FROM threats WHERE status = 'ACTIVE') as active_threats,
        (SELECT COUNT(*) FROM systems WHERE status = 'ACTIVE') as active_systems,
        (SELECT COUNT(*) FROM systems WHERE vulnerability_level IN ('HIGH', 'CRITICAL')) as high_risk_systems,
        (SELECT COUNT(*) FROM incidents WHERE DATE(detected_at) = CURDATE()) as incidents_today,
        (SELECT COUNT(*) FROM logs WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as logs_24h;
END //

-- Procedure: Get Incident Statistics by Severity
CREATE PROCEDURE GetIncidentStatsBySeverity()
BEGIN
    SELECT 
        severity,
        COUNT(*) as count,
        ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM incidents), 2) as percentage
    FROM incidents
    GROUP BY severity
    ORDER BY FIELD(severity, 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW');
END //

-- Procedure: Get System Risk Distribution
CREATE PROCEDURE GetSystemRiskDistribution()
BEGIN
    SELECT 
        vulnerability_level,
        COUNT(*) as count
    FROM systems
    GROUP BY vulnerability_level
    ORDER BY FIELD(vulnerability_level, 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW');
END //

DELIMITER ;
