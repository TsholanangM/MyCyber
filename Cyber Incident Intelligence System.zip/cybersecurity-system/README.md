# Cybersecurity Incident Intelligence System

## System Architecture

### Overview
The Cybersecurity Incident Intelligence System is a full-stack application designed to manage, analyze, and predict cybersecurity threats using a data-driven approach with AI/ML capabilities.

### Architecture Components

```
┌─────────────────────────────────────────────────────────────┐
│                     CLIENT LAYER                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │   Angular   │  │   Chart.js  │  │   JWT Auth  │       │
│  │  Frontend   │  │   Charts    │  │   Client    │       │
│  └──────┬──────┘  └─────────────┘  └─────────────┘       │
└─────────┼───────────────────────────────────────────────────┘
          │ HTTP/REST
          ▼
┌─────────────────────────────────────────────────────────────┐
│                     API GATEWAY LAYER                        │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │              Spring Boot Application                     │ │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────────┐ │ │
│  │  │   Auth  │ │ Incident│ │ Threat  │ │   System    │ │ │
│  │  │ Controller│ │Controller│ │Controller│ │  Controller │ │ │
│  │  └────┬────┘ └────┬────┘ └────┬────┘ └──────┬──────┘ │ │
│  │       └───────────┴───────────┴─────────────┘          │ │
│  │                    Service Layer                        │ │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────────┐ │ │
│  │  │  User   │ │ Incident│ │ Threat  │ │   System    │ │ │
│  │  │ Service │ │ Service │ │ Service │ │   Service   │ │ │
│  │  └────┬────┘ └────┬────┘ └────┬────┘ └──────┬──────┘ │ │
│  │       └───────────┴───────────┴─────────────┘          │ │
│  │                   Repository Layer                      │ │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────────┐ │ │
│  │  │  User   │ │ Incident│ │ Threat  │ │   System    │ │ │
│  │  │   Repo  │ │   Repo  │ │   Repo  │ │    Repo     │ │ │
│  │  └────┬────┘ └────┬────┘ └────┬────┘ └──────┬──────┘ │ │
│  └───────┼───────────┼───────────┼─────────────┼────────┘ │
│          │           │           │             │          │
│  ┌───────┴───────────┴───────────┴─────────────┴────────┐ │
│  │              Security Layer                             │ │
│  │  • JWT Authentication                                   │ │
│  │  • Role-Based Access Control                            │ │
│  │  • BCrypt Password Encryption                           │ │
│  └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
          │
          ▼ JDBC
┌─────────────────────────────────────────────────────────────┐
│                     DATA LAYER                               │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │                 MySQL Database                         │ │
│  │  • Users        • Incidents      • Threats             │ │
│  │  • Systems      • Logs           • AttackTypes         │ │
│  │  • AI Predictions             • System Metrics         │ │
│  └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
          │
          ▼ HTTP
┌─────────────────────────────────────────────────────────────┐
│                     AI/ML LAYER                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │              PyTorch Flask Service                     │ │
│  │  • Attack Likelihood Predictor                          │ │
│  │  • Severity Classifier                                  │ │
│  │  • Risk Score Calculator                                │ │
│  │  • Anomaly Detector                                     │ │
│  └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Technology Stack

### Frontend
- **Framework**: Angular 17
- **Language**: TypeScript
- **Styling**: SCSS, Bootstrap 5
- **Charts**: Chart.js with ng2-charts
- **UI Components**: Font Awesome Icons
- **HTTP Client**: Angular HttpClient
- **Authentication**: JWT with angular-jwt
- **Notifications**: ngx-toastr

### Backend
- **Framework**: Spring Boot 3.2.0
- **Language**: Java 17
- **ORM**: Hibernate/JPA
- **Database**: MySQL 8.0+
- **Security**: Spring Security with JWT
- **Documentation**: OpenAPI 3.0 (Swagger)
- **Build Tool**: Maven

### AI/ML Service
- **Framework**: PyTorch 2.1.0
- **Language**: Python 3.9+
- **API**: Flask 3.0.0
- **Data Processing**: NumPy, Pandas
- **ML Utilities**: scikit-learn

### Database
- **Engine**: MySQL 8.0+
- **Connection Pooling**: HikariCP
- **Migration**: Hibernate DDL

## Database Schema

### Entity Relationship Diagram

```
┌─────────────┐       ┌─────────────────┐       ┌─────────────┐
│   users     │       │    incidents    │       │  threats    │
├─────────────┤       ├─────────────────┤       ├─────────────┤
│ id (PK)     │◄──────│ reported_by(FK) │       │ id (PK)     │
│ name        │       │ assigned_to(FK) │◄─────│ detected_by │
│ email       │       │ attack_type_id  │◄─────│ attack_type │
│ password    │       │ affected_system │◄─────│ affected_sys│
│ role        │       │ threat_id (FK)  │◄─────┘             │
│ is_active   │       │                 │                      │
└─────────────┘       └─────────────────┘                      │
         ▲                                              │
         │                                              │
         │         ┌─────────────────┐                  │
         │         │  attack_types   │◄─────────────────┘
         │         ├─────────────────┤
         │         │ id (PK)         │
         │         │ name            │
         │         │ description     │
         │         │ severity_weight │
         │         └─────────────────┘
         │
         │         ┌─────────────────┐
         │         │    systems      │
         │         ├─────────────────┤
         └─────────│ id (PK)         │
                   │ system_name     │
                   │ owner           │
                   │ vulnerability   │
                   │ system_type     │
                   │ status          │
                   └─────────────────┘

┌─────────────────┐       ┌─────────────────┐
│     logs        │       │  ai_predictions │
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ user_id (FK)    │◄──────│ entity_type     │
│ action          │       │ entity_id       │
│ entity_type     │       │ prediction_type │
│ entity_id       │       │ prediction_value│
│ severity        │       │ confidence_score│
│ timestamp       │       │ model_version   │
└─────────────────┘       └─────────────────┘
```

## API Documentation

### Authentication Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/login` | User login | No |
| POST | `/api/auth/register` | User registration | No |
| POST | `/api/auth/refresh` | Refresh JWT token | No |

### User Endpoints

| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/users` | List all users | ADMIN, ANALYST |
| GET | `/api/users/{id}` | Get user by ID | ADMIN, ANALYST, Self |
| POST | `/api/users` | Create user | ADMIN |
| PUT | `/api/users/{id}` | Update user | ADMIN |
| DELETE | `/api/users/{id}` | Delete user | ADMIN |
| GET | `/api/users/search` | Search users | ADMIN, ANALYST |

### Incident Endpoints

| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/incidents` | List incidents | All |
| GET | `/api/incidents/{id}` | Get incident | All |
| POST | `/api/incidents` | Create incident | ADMIN, ANALYST |
| PUT | `/api/incidents/{id}` | Update incident | ADMIN, ANALYST |
| PATCH | `/api/incidents/{id}/status` | Update status | ADMIN, ANALYST |
| DELETE | `/api/incidents/{id}` | Delete incident | ADMIN |
| GET | `/api/incidents/search` | Search incidents | All |

### Threat Endpoints

| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/threats` | List threats | All |
| GET | `/api/threats/{id}` | Get threat | All |
| POST | `/api/threats` | Create threat | ADMIN, ANALYST |
| PUT | `/api/threats/{id}` | Update threat | ADMIN, ANALYST |
| PATCH | `/api/threats/{id}/status` | Update status | ADMIN, ANALYST |
| DELETE | `/api/threats/{id}` | Delete threat | ADMIN |

### System Endpoints

| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/systems` | List systems | All |
| GET | `/api/systems/{id}` | Get system | All |
| POST | `/api/systems` | Create system | ADMIN, ANALYST |
| PUT | `/api/systems/{id}` | Update system | ADMIN, ANALYST |
| PATCH | `/api/systems/{id}/status` | Update status | ADMIN, ANALYST |
| DELETE | `/api/systems/{id}` | Delete system | ADMIN |

### Dashboard Endpoints

| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/dashboard/stats` | Get dashboard stats | All |
| GET | `/api/dashboard/incident-trends` | Incident trends | ADMIN, ANALYST |
| GET | `/api/dashboard/threat-intelligence` | Threat intel | ADMIN, ANALYST |
| GET | `/api/dashboard/system-health` | System health | ADMIN, ANALYST |

### AI Prediction Endpoints

| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/predictions/attack-likelihood/{systemId}` | Predict attack | ADMIN, ANALYST |
| POST | `/api/predictions/incident-severity/{incidentId}` | Classify severity | ADMIN, ANALYST |
| GET | `/api/predictions/risk-score/{systemId}` | Risk score | ADMIN, ANALYST |
| POST | `/api/predictions/detect-anomaly` | Detect anomaly | ADMIN, ANALYST |
| GET | `/api/predictions/model-status` | Model status | ADMIN, ANALYST |

## Setup Instructions

### Prerequisites
- Java 17+
- Node.js 18+
- Python 3.9+
- MySQL 8.0+
- Maven 3.8+

### 1. Database Setup

```bash
# Login to MySQL
mysql -u root -p

# Create database (or use provided schema.sql)
source database/schema.sql
```

### 2. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Update application.yml with your database credentials
# src/main/resources/application.yml

# Build and run
mvn clean install
mvn spring-boot:run

# Or run the JAR
java -jar target/cybersecurity-incident-system-1.0.0.jar
```

### 3. AI Service Setup

```bash
# Navigate to AI model directory
cd ai-model

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the Flask application
python app.py
```

### 4. Frontend Setup

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start development server
ng serve

# Or build for production
ng build --configuration production
```

### 5. Access the Application

- Frontend: http://localhost:4200
- Backend API: http://localhost:8080/api
- AI Service: http://localhost:5000
- API Documentation: http://localhost:8080/api/swagger-ui.html

### Default Login Credentials
- Admin: admin@cybersec.com / password123
- Analyst: analyst@cybersec.com / password123
- User: operator@cybersec.com / password123

## Security Features

### Authentication & Authorization
- JWT-based authentication with refresh tokens
- Role-based access control (RBAC)
- BCrypt password encryption (strength 10)
- Token expiration and validation

### API Security
- CORS configuration
- Input validation
- SQL injection prevention (JPA/Hibernate)
- XSS protection through output encoding

### Data Security
- Passwords hashed with BCrypt
- Sensitive data encrypted at rest
- Secure communication (HTTPS in production)
- Audit logging for all actions

## AI/ML Features

### Prediction Models
1. **Attack Likelihood Predictor**
   - Input: System vulnerability metrics
   - Output: Risk level (LOW/MEDIUM/HIGH/CRITICAL)
   - Model: Feed-forward neural network

2. **Severity Classifier**
   - Input: Incident features
   - Output: Severity classification
   - Model: Multi-class classifier

3. **Risk Score Calculator**
   - Input: System security metrics
   - Output: Risk score (0-100)
   - Model: Regression neural network

4. **Anomaly Detector**
   - Input: System metrics
   - Output: Anomaly score and detection
   - Model: Autoencoder

## Monitoring & Logging

### Application Logs
- Location: `logs/cybersec-application.log`
- Format: timestamp, thread, level, logger, message
- Levels: INFO, WARN, ERROR, DEBUG

### Activity Logging
- All user actions logged
- Entity change tracking
- IP address and user agent recording
- Severity-based log classification

## Performance Optimization

### Database
- Connection pooling (HikariCP)
- Query optimization with indexes
- Batch processing for bulk operations
- Lazy loading for relationships

### Caching Strategy
- Redis integration ready
- Application-level caching
- Database query caching

## Deployment

### Docker Deployment (Optional)
```dockerfile
# Dockerfile for backend
FROM openjdk:17-jdk-slim
COPY target/*.jar app.jar
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

### Production Checklist
- [ ] Enable HTTPS
- [ ] Configure production database
- [ ] Set up environment variables
- [ ] Enable logging aggregation
- [ ] Configure monitoring alerts
- [ ] Set up backup strategy
- [ ] Enable rate limiting
- [ ] Configure CORS for production
- [ ] Set up CI/CD pipeline
- [ ] Performance testing

## Support & Maintenance

### Troubleshooting
1. Database connection issues
   - Check MySQL service status
   - Verify credentials in application.yml
   - Check firewall settings

2. JWT token issues
   - Verify token expiration
   - Check system clock synchronization
   - Validate secret key configuration

3. AI service connection issues
   - Verify Python environment
   - Check Flask service status
   - Validate network connectivity

### Updates
- Regular security patches
- Dependency updates
- Model retraining schedule
- Database maintenance windows

## License
MIT License - See LICENSE file for details

## Contact
For support or inquiries, contact: security@cybersec.com