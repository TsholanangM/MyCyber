"""
Flask API for Cybersecurity Threat Prediction Model
Provides RESTful endpoints for AI predictions
"""

import os
import sys
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

# Add models directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from models.threat_predictor import get_model, ThreatPredictionModel

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# Configuration
MODEL_PATH = os.getenv('MODEL_PATH', 'models/saved/threat_model.pt')
PORT = int(os.getenv('PORT', 5000))
DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'

# Initialize model
print("Initializing AI models...")
model = get_model(MODEL_PATH)
print("Models initialized successfully!")


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'service': 'cybersecurity-ai-model'
    })


@app.route('/status', methods=['GET'])
def model_status():
    """Get model status and information"""
    return jsonify({
        'status': 'ready',
        'model_version': '1.0.0',
        'models_loaded': {
            'attack_predictor': True,
            'severity_classifier': True,
            'risk_calculator': True,
            'anomaly_detector': True
        },
        'supported_predictions': [
            'ATTACK_LIKELIHOOD',
            'SEVERITY_CLASSIFICATION',
            'RISK_SCORE',
            'ANOMALY_DETECTION'
        ],
        'timestamp': datetime.now().isoformat()
    })


@app.route('/predict', methods=['POST'])
def predict():
    """
    Main prediction endpoint
    
    Request body:
    {
        "predictionType": "ATTACK_LIKELIHOOD|SEVERITY_CLASSIFICATION|RISK_SCORE|ANOMALY_DETECTION",
        "entityType": "SYSTEM|INCIDENT|THREAT",
        "entityId": 123,
        "features": { ... }
    }
    
    Response:
    {
        "prediction": "...",
        "confidence": 0.95,
        "details": { ... }
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        prediction_type = data.get('predictionType')
        features = data.get('features', {})
        
        if not prediction_type:
            return jsonify({'error': 'predictionType is required'}), 400
        
        # Route to appropriate model
        if prediction_type == 'ATTACK_LIKELIHOOD':
            result = model.predict_attack_likelihood(features)
        elif prediction_type == 'SEVERITY_CLASSIFICATION':
            result = model.classify_severity(features)
        elif prediction_type == 'RISK_SCORE':
            result = model.calculate_risk_score(features)
        elif prediction_type == 'ANOMALY_DETECTION':
            result = model.detect_anomaly(features)
        else:
            return jsonify({'error': f'Unknown prediction type: {prediction_type}'}), 400
        
        # Add metadata to response
        result['model_version'] = '1.0.0'
        result['timestamp'] = datetime.now().isoformat()
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'error': 'Prediction failed',
            'message': str(e)
        }), 500


@app.route('/predict/attack-likelihood', methods=['POST'])
def predict_attack_likelihood():
    """Predict attack likelihood for a system"""
    try:
        data = request.get_json()
        features = data.get('features', {})
        
        result = model.predict_attack_likelihood(features)
        result['model_version'] = '1.0.0'
        result['timestamp'] = datetime.now().isoformat()
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predict/severity', methods=['POST'])
def predict_severity():
    """Classify incident severity"""
    try:
        data = request.get_json()
        features = data.get('features', {})
        
        result = model.classify_severity(features)
        result['model_version'] = '1.0.0'
        result['timestamp'] = datetime.now().isoformat()
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predict/risk-score', methods=['POST'])
def predict_risk_score():
    """Calculate system risk score"""
    try:
        data = request.get_json()
        features = data.get('features', {})
        
        result = model.calculate_risk_score(features)
        result['model_version'] = '1.0.0'
        result['timestamp'] = datetime.now().isoformat()
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predict/anomaly', methods=['POST'])
def predict_anomaly():
    """Detect anomalies in system metrics"""
    try:
        data = request.get_json()
        metrics = data.get('features', {})
        
        result = model.detect_anomaly(metrics)
        result['model_version'] = '1.0.0'
        result['timestamp'] = datetime.now().isoformat()
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/batch-predict', methods=['POST'])
def batch_predict():
    """
    Batch prediction endpoint for multiple predictions
    
    Request body:
    {
        "predictions": [
            {
                "predictionType": "...",
                "features": { ... }
            },
            ...
        ]
    }
    """
    try:
        data = request.get_json()
        predictions = data.get('predictions', [])
        
        if not predictions:
            return jsonify({'error': 'No predictions provided'}), 400
        
        results = []
        for pred in predictions:
            prediction_type = pred.get('predictionType')
            features = pred.get('features', {})
            
            if prediction_type == 'ATTACK_LIKELIHOOD':
                result = model.predict_attack_likelihood(features)
            elif prediction_type == 'SEVERITY_CLASSIFICATION':
                result = model.classify_severity(features)
            elif prediction_type == 'RISK_SCORE':
                result = model.calculate_risk_score(features)
            elif prediction_type == 'ANOMALY_DETECTION':
                result = model.detect_anomaly(features)
            else:
                result = {'error': f'Unknown prediction type: {prediction_type}'}
            
            results.append(result)
        
        return jsonify({
            'results': results,
            'count': len(results),
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500


if __name__ == '__main__':
    print(f"Starting AI Service on port {PORT}")
    print(f"Debug mode: {DEBUG}")
    app.run(host='0.0.0.0', port=PORT, debug=DEBUG)
