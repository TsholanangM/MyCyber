"""
Cybersecurity Threat Prediction Model using PyTorch
This module implements neural network models for:
1. Attack likelihood prediction
2. Incident severity classification
3. System risk score calculation
4. Anomaly detection
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional
import json


class AttackLikelihoodPredictor(nn.Module):
    """
    Neural Network for predicting the likelihood of a cyber attack on a system.
    Uses system vulnerability metrics and historical data.
    """
    
    def __init__(self, input_size: int = 10, hidden_size: int = 64):
        super(AttackLikelihoodPredictor, self).__init__()
        
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.bn1 = nn.BatchNorm1d(hidden_size)
        self.dropout1 = nn.Dropout(0.3)
        
        self.fc2 = nn.Linear(hidden_size, hidden_size // 2)
        self.bn2 = nn.BatchNorm1d(hidden_size // 2)
        self.dropout2 = nn.Dropout(0.3)
        
        self.fc3 = nn.Linear(hidden_size // 2, 1)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout1(x)
        
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout2(x)
        
        x = torch.sigmoid(self.fc3(x))
        return x


class SeverityClassifier(nn.Module):
    """
    Neural Network for classifying incident severity.
    Outputs: LOW, MEDIUM, HIGH, CRITICAL
    """
    
    def __init__(self, input_size: int = 15, num_classes: int = 4):
        super(SeverityClassifier, self).__init__()
        
        self.fc1 = nn.Linear(input_size, 128)
        self.bn1 = nn.BatchNorm1d(128)
        self.dropout1 = nn.Dropout(0.4)
        
        self.fc2 = nn.Linear(128, 64)
        self.bn2 = nn.BatchNorm1d(64)
        self.dropout2 = nn.Dropout(0.3)
        
        self.fc3 = nn.Linear(64, 32)
        self.bn3 = nn.BatchNorm1d(32)
        
        self.fc4 = nn.Linear(32, num_classes)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout1(x)
        
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout2(x)
        
        x = F.relu(self.bn3(self.fc3(x)))
        
        x = self.fc4(x)
        return x


class RiskScoreCalculator(nn.Module):
    """
    Neural Network for calculating a comprehensive risk score (0-100) for systems.
    """
    
    def __init__(self, input_size: int = 12):
        super(RiskScoreCalculator, self).__init__()
        
        self.fc1 = nn.Linear(input_size, 64)
        self.bn1 = nn.BatchNorm1d(64)
        self.dropout1 = nn.Dropout(0.3)
        
        self.fc2 = nn.Linear(64, 32)
        self.bn2 = nn.BatchNorm1d(32)
        self.dropout2 = nn.Dropout(0.2)
        
        self.fc3 = nn.Linear(32, 16)
        self.bn3 = nn.BatchNorm1d(16)
        
        self.fc4 = nn.Linear(16, 1)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout1(x)
        
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.dropout2(x)
        
        x = F.relu(self.bn3(self.fc3(x)))
        
        x = torch.sigmoid(self.fc4(x)) * 100  # Scale to 0-100
        return x


class AnomalyDetector(nn.Module):
    """
    Autoencoder-based anomaly detection model.
    Uses reconstruction error to detect anomalies in system metrics.
    """
    
    def __init__(self, input_size: int = 8):
        super(AnomalyDetector, self).__init__()
        
        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_size, 16),
            nn.ReLU(),
            nn.Linear(16, 8),
            nn.ReLU(),
            nn.Linear(8, 4)
        )
        
        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(4, 8),
            nn.ReLU(),
            nn.Linear(8, 16),
            nn.ReLU(),
            nn.Linear(16, input_size),
            nn.Sigmoid()
        )
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded, encoded
    
    def calculate_anomaly_score(self, x: torch.Tensor) -> torch.Tensor:
        """Calculate reconstruction error as anomaly score"""
        reconstructed, _ = self.forward(x)
        mse = F.mse_loss(reconstructed, x, reduction='none')
        return mse.mean(dim=1)


class ThreatPredictionModel:
    """
    Main class that manages all prediction models and provides unified interface.
    """
    
    def __init__(self, model_path: Optional[str] = None):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Initialize models
        self.attack_predictor = AttackLikelihoodPredictor().to(self.device)
        self.severity_classifier = SeverityClassifier().to(self.device)
        self.risk_calculator = RiskScoreCalculator().to(self.device)
        self.anomaly_detector = AnomalyDetector().to(self.device)
        
        # Severity mapping
        self.severity_map = {0: 'LOW', 1: 'MEDIUM', 2: 'HIGH', 3: 'CRITICAL'}
        
        if model_path:
            self.load_models(model_path)
    
    def predict_attack_likelihood(self, features: Dict) -> Dict:
        """
        Predict the likelihood of an attack on a system.
        
        Args:
            features: Dictionary containing system features
            
        Returns:
            Dictionary with prediction and confidence
        """
        self.attack_predictor.eval()
        
        # Extract and normalize features
        input_features = self._extract_attack_features(features)
        input_tensor = torch.FloatTensor(input_features).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            prediction = self.attack_predictor(input_tensor)
            likelihood = prediction.item()
        
        # Determine risk level
        if likelihood < 0.3:
            risk_level = 'LOW'
        elif likelihood < 0.6:
            risk_level = 'MEDIUM'
        elif likelihood < 0.8:
            risk_level = 'HIGH'
        else:
            risk_level = 'CRITICAL'
        
        return {
            'prediction': risk_level,
            'likelihood_score': round(likelihood * 100, 2),
            'confidence': round(1 - abs(0.5 - likelihood) * 2, 2),
            'details': {
                'raw_score': round(likelihood, 4),
                'recommendation': self._get_recommendation(risk_level)
            }
        }
    
    def classify_severity(self, features: Dict) -> Dict:
        """
        Classify the severity of an incident.
        
        Args:
            features: Dictionary containing incident features
            
        Returns:
            Dictionary with classification and confidence
        """
        self.severity_classifier.eval()
        
        input_features = self._extract_severity_features(features)
        input_tensor = torch.FloatTensor(input_features).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            outputs = self.severity_classifier(input_tensor)
            probabilities = F.softmax(outputs, dim=1)
            predicted_class = torch.argmax(probabilities, dim=1).item()
            confidence = probabilities[0][predicted_class].item()
        
        # Get all class probabilities
        all_probs = probabilities[0].cpu().numpy()
        
        return {
            'prediction': self.severity_map[predicted_class],
            'confidence': round(confidence, 4),
            'details': {
                'class_probabilities': {
                    self.severity_map[i]: round(prob, 4) 
                    for i, prob in enumerate(all_probs)
                },
                'factors': self._get_severity_factors(features)
            }
        }
    
    def calculate_risk_score(self, features: Dict) -> Dict:
        """
        Calculate comprehensive risk score for a system.
        
        Args:
            features: Dictionary containing system features
            
        Returns:
            Dictionary with risk score and breakdown
        """
        self.risk_calculator.eval()
        
        input_features = self._extract_risk_features(features)
        input_tensor = torch.FloatTensor(input_features).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            risk_score = self.risk_calculator(input_tensor).item()
        
        # Determine risk category
        if risk_score < 25:
            category = 'LOW'
        elif risk_score < 50:
            category = 'MEDIUM'
        elif risk_score < 75:
            category = 'HIGH'
        else:
            category = 'CRITICAL'
        
        return {
            'prediction': category,
            'risk_score': round(risk_score, 2),
            'confidence': round(min(risk_score / 100 + 0.5, 0.95), 2),
            'details': {
                'score_breakdown': self._get_risk_breakdown(features),
                'recommendations': self._get_risk_recommendations(category)
            }
        }
    
    def detect_anomaly(self, metrics: Dict) -> Dict:
        """
        Detect anomalies in system metrics.
        
        Args:
            metrics: Dictionary containing system metrics
            
        Returns:
            Dictionary with anomaly detection results
        """
        self.anomaly_detector.eval()
        
        input_features = self._extract_anomaly_features(metrics)
        input_tensor = torch.FloatTensor(input_features).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            anomaly_score = self.anomaly_detector.calculate_anomaly_score(input_tensor).item()
        
        # Determine if anomaly (threshold can be tuned)
        threshold = 0.5
        is_anomaly = anomaly_score > threshold
        
        if anomaly_score < 0.3:
            severity = 'LOW'
        elif anomaly_score < 0.6:
            severity = 'MEDIUM'
        elif anomaly_score < 0.9:
            severity = 'HIGH'
        else:
            severity = 'CRITICAL'
        
        return {
            'prediction': 'ANOMALY_DETECTED' if is_anomaly else 'NORMAL',
            'anomaly_score': round(anomaly_score, 4),
            'confidence': round(min(anomaly_score * 2, 0.95), 2) if is_anomaly else round(1 - anomaly_score, 2),
            'details': {
                'threshold': threshold,
                'severity': severity,
                'affected_metrics': self._get_affected_metrics(metrics) if is_anomaly else []
            }
        }
    
    def _extract_attack_features(self, features: Dict) -> List[float]:
        """Extract and normalize features for attack prediction"""
        return [
            float(features.get('vulnerability_level', 0)) / 4.0,
            float(features.get('failed_logins_24h', 0)) / 100.0,
            float(features.get('port_scans_detected', 0)) / 50.0,
            float(features.get('malware_detections', 0)) / 10.0,
            float(features.get('unusual_traffic', 0)),
            float(features.get('patch_age_days', 0)) / 365.0,
            float(features.get('open_ports', 0)) / 100.0,
            float(features.get('privilege_escalations', 0)) / 10.0,
            float(features.get('data_exfiltration_attempts', 0)) / 10.0,
            float(features.get('previous_breaches', 0)) / 5.0
        ]
    
    def _extract_severity_features(self, features: Dict) -> List[float]:
        """Extract and normalize features for severity classification"""
        return [
            float(features.get('affected_systems_count', 1)) / 10.0,
            float(features.get('data_at_risk', 0)),
            float(features.get('service_disruption', 0)),
            float(features.get('financial_impact', 0)) / 1000000.0,
            float(features.get('reputational_risk', 0)),
            float(features.get('regulatory_implications', 0)),
            float(features.get('attack_complexity', 0)) / 5.0,
            float(features.get('attack_vector', 0)) / 5.0,
            float(features.get('privileges_required', 0)) / 3.0,
            float(features.get('user_interaction', 0)),
            float(features.get('scope', 0)) / 3.0,
            float(features.get('confidentiality_impact', 0)) / 3.0,
            float(features.get('integrity_impact', 0)) / 3.0,
            float(features.get('availability_impact', 0)) / 3.0,
            float(features.get('exploit_maturity', 0)) / 4.0
        ]
    
    def _extract_risk_features(self, features: Dict) -> List[float]:
        """Extract and normalize features for risk calculation"""
        return [
            float(features.get('vulnerability_score', 0)) / 10.0,
            float(features.get('threat_exposure', 0)),
            float(features.get('asset_value', 0)) / 100.0,
            float(features.get('control_effectiveness', 0)),
            float(features.get('incident_history', 0)) / 10.0,
            float(features.get('patch_management', 0)),
            float(features.get('access_controls', 0)),
            float(features.get('monitoring_coverage', 0)),
            float(features.get('backup_effectiveness', 0)),
            float(features.get('staff_training', 0)),
            float(features.get('compliance_score', 0)) / 100.0,
            float(features.get('business_continuity', 0))
        ]
    
    def _extract_anomaly_features(self, metrics: Dict) -> List[float]:
        """Extract and normalize features for anomaly detection"""
        return [
            float(metrics.get('cpu_usage', 0)) / 100.0,
            float(metrics.get('memory_usage', 0)) / 100.0,
            float(metrics.get('disk_usage', 0)) / 100.0,
            float(metrics.get('network_in', 0)) / 1000.0,
            float(metrics.get('network_out', 0)) / 1000.0,
            float(metrics.get('failed_logins', 0)) / 100.0,
            float(metrics.get('process_count', 0)) / 500.0,
            float(metrics.get('connection_count', 0)) / 1000.0
        ]
    
    def _get_recommendation(self, risk_level: str) -> str:
        """Get recommendation based on risk level"""
        recommendations = {
            'LOW': 'Continue regular monitoring and maintenance.',
            'MEDIUM': 'Review security controls and consider additional monitoring.',
            'HIGH': 'Immediate review required. Implement additional security measures.',
            'CRITICAL': 'URGENT: Take immediate action to secure the system.'
        }
        return recommendations.get(risk_level, 'Review system security.')
    
    def _get_severity_factors(self, features: Dict) -> List[str]:
        """Get factors contributing to severity"""
        factors = []
        if features.get('data_at_risk', 0) > 0.5:
            factors.append('Sensitive data at risk')
        if features.get('service_disruption', 0) > 0.5:
            factors.append('Service disruption likely')
        if features.get('financial_impact', 0) > 100000:
            factors.append('High financial impact')
        return factors
    
    def _get_risk_breakdown(self, features: Dict) -> Dict:
        """Get breakdown of risk components"""
        return {
            'vulnerability': round(features.get('vulnerability_score', 0) * 10, 2),
            'threat_exposure': round(features.get('threat_exposure', 0) * 100, 2),
            'asset_value': round(features.get('asset_value', 0), 2),
            'control_gaps': round((1 - features.get('control_effectiveness', 0)) * 100, 2)
        }
    
    def _get_risk_recommendations(self, category: str) -> List[str]:
        """Get recommendations based on risk category"""
        recommendations = {
            'LOW': ['Maintain current security posture', 'Continue regular monitoring'],
            'MEDIUM': ['Review and update security controls', 'Increase monitoring frequency'],
            'HIGH': ['Implement additional security measures', 'Conduct security audit', 'Enhance monitoring'],
            'CRITICAL': ['Immediate remediation required', 'Isolate affected systems', 'Escalate to security team']
        }
        return recommendations.get(category, ['Review security posture'])
    
    def _get_affected_metrics(self, metrics: Dict) -> List[str]:
        """Get list of metrics that indicate anomaly"""
        affected = []
        if metrics.get('cpu_usage', 0) > 90:
            affected.append('CPU usage')
        if metrics.get('memory_usage', 0) > 90:
            affected.append('Memory usage')
        if metrics.get('failed_logins', 0) > 10:
            affected.append('Failed login attempts')
        if metrics.get('network_in', 0) > 800:
            affected.append('Network inbound traffic')
        return affected
    
    def save_models(self, path: str):
        """Save all models to disk"""
        torch.save({
            'attack_predictor': self.attack_predictor.state_dict(),
            'severity_classifier': self.severity_classifier.state_dict(),
            'risk_calculator': self.risk_calculator.state_dict(),
            'anomaly_detector': self.anomaly_detector.state_dict()
        }, path)
    
    def load_models(self, path: str):
        """Load all models from disk"""
        try:
            checkpoint = torch.load(path, map_location=self.device)
            self.attack_predictor.load_state_dict(checkpoint['attack_predictor'])
            self.severity_classifier.load_state_dict(checkpoint['severity_classifier'])
            self.risk_calculator.load_state_dict(checkpoint['risk_calculator'])
            self.anomaly_detector.load_state_dict(checkpoint['anomaly_detector'])
        except Exception as e:
            print(f"Could not load models: {e}. Using initialized weights.")


# Singleton instance
_model_instance = None

def get_model(model_path: Optional[str] = None) -> ThreatPredictionModel:
    """Get or create singleton model instance"""
    global _model_instance
    if _model_instance is None:
        _model_instance = ThreatPredictionModel(model_path)
    return _model_instance
