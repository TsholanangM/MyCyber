package com.cybersec.controller;

import com.cybersec.dto.ApiResponse;
import com.cybersec.dto.IncidentDTO;
import com.cybersec.dto.PageResponse;
import com.cybersec.enums.IncidentSeverity;
import com.cybersec.enums.IncidentStatus;
import com.cybersec.security.UserPrincipal;
import com.cybersec.service.IncidentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/incidents")
@RequiredArgsConstructor
@Tag(name = "Incidents", description = "Incident management APIs")
@SecurityRequirement(name = "bearerAuth")
public class IncidentController {

    private final IncidentService incidentService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get all incidents", description = "Retrieve paginated list of all incidents")
    public ResponseEntity<ApiResponse<PageResponse<IncidentDTO>>> getAllIncidents(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "detectedAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        Page<IncidentDTO> incidents = incidentService.getAllIncidents(page, size, sortBy, direction);
        PageResponse<IncidentDTO> response = PageResponse.<IncidentDTO>builder()
                .content(incidents.getContent())
                .pageNumber(incidents.getNumber())
                .pageSize(incidents.getSize())
                .totalElements(incidents.getTotalElements())
                .totalPages(incidents.getTotalPages())
                .first(incidents.isFirst())
                .last(incidents.isLast())
                .empty(incidents.isEmpty())
                .build();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get incident by ID", description = "Retrieve incident details by ID")
    public ResponseEntity<ApiResponse<IncidentDTO>> getIncidentById(@PathVariable Long id) {
        IncidentDTO incident = incidentService.getIncidentById(id);
        return ResponseEntity.ok(ApiResponse.success(incident));
    }

    @GetMapping("/number/{incidentNumber}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get incident by number", description = "Retrieve incident by incident number")
    public ResponseEntity<ApiResponse<IncidentDTO>> getIncidentByNumber(@PathVariable String incidentNumber) {
        IncidentDTO incident = incidentService.getIncidentByNumber(incidentNumber);
        return ResponseEntity.ok(ApiResponse.success(incident));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Create incident", description = "Create a new incident")
    public ResponseEntity<ApiResponse<IncidentDTO>> createIncident(
            @Valid @RequestBody IncidentDTO incidentDTO,
            @AuthenticationPrincipal UserPrincipal currentUser) {
        IncidentDTO incident = incidentService.createIncident(incidentDTO, currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("Incident created successfully", incident));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Update incident", description = "Update incident details")
    public ResponseEntity<ApiResponse<IncidentDTO>> updateIncident(
            @PathVariable Long id,
            @Valid @RequestBody IncidentDTO incidentDTO) {
        IncidentDTO incident = incidentService.updateIncident(id, incidentDTO);
        return ResponseEntity.ok(ApiResponse.success("Incident updated successfully", incident));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Update incident status", description = "Update incident status")
    public ResponseEntity<ApiResponse<IncidentDTO>> updateIncidentStatus(
            @PathVariable Long id,
            @RequestParam IncidentStatus status) {
        IncidentDTO incident = incidentService.updateIncidentStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Status updated successfully", incident));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete incident", description = "Delete an incident (Admin only)")
    public ResponseEntity<ApiResponse<Void>> deleteIncident(@PathVariable Long id) {
        incidentService.deleteIncident(id);
        return ResponseEntity.ok(ApiResponse.success("Incident deleted successfully", null));
    }

    @GetMapping("/search")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Search incidents", description = "Search and filter incidents")
    public ResponseEntity<ApiResponse<PageResponse<IncidentDTO>>> searchIncidents(
            @RequestParam(required = false) IncidentStatus status,
            @RequestParam(required = false) IncidentSeverity severity,
            @RequestParam(required = false) Long assignedTo,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<IncidentDTO> incidents = incidentService.searchIncidents(status, severity, assignedTo, search, page, size);
        PageResponse<IncidentDTO> response = PageResponse.<IncidentDTO>builder()
                .content(incidents.getContent())
                .pageNumber(incidents.getNumber())
                .pageSize(incidents.getSize())
                .totalElements(incidents.getTotalElements())
                .totalPages(incidents.getTotalPages())
                .first(incidents.isFirst())
                .last(incidents.isLast())
                .empty(incidents.isEmpty())
                .build();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/recent")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get recent incidents", description = "Retrieve recent incidents")
    public ResponseEntity<ApiResponse<List<IncidentDTO>>> getRecentIncidents(
            @RequestParam(defaultValue = "5") int limit) {
        List<IncidentDTO> incidents = incidentService.getRecentIncidents(limit);
        return ResponseEntity.ok(ApiResponse.success(incidents));
    }

    @GetMapping("/stats/by-severity")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Incident stats by severity", description = "Get incident count by severity")
    public ResponseEntity<ApiResponse<Map<String, Long>>> getStatsBySeverity() {
        Map<String, Long> stats = incidentService.getIncidentStatsBySeverity();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }

    @GetMapping("/stats/by-status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Incident stats by status", description = "Get incident count by status")
    public ResponseEntity<ApiResponse<Map<String, Long>>> getStatsByStatus() {
        Map<String, Long> stats = incidentService.getIncidentStatsByStatus();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}
