package com.cybersec.repository;

import com.cybersec.entity.AttackType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AttackTypeRepository extends JpaRepository<AttackType, Long> {
    
    Optional<AttackType> findByName(String name);
    
    boolean existsByName(String name);
}
