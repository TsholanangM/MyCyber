package com.cybersec.enums;

public enum SystemStatus {
    ACTIVE,
    INACTIVE,
    MAINTENANCE,
    COMPROMISED
}
