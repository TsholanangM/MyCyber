package com.cybersec.repository;

import com.cybersec.entity.System;
import com.cybersec.enums.SystemStatus;
import com.cybersec.enums.VulnerabilityLevel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SystemRepository extends JpaRepository<System, Long> {
    
    Optional<System> findBySystemName(String systemName);
    
    List<System> findByStatus(SystemStatus status);
    
    List<System> findByVulnerabilityLevel(VulnerabilityLevel vulnerabilityLevel);
    
    @Query("SELECT COUNT(s) FROM System s WHERE s.status = 'ACTIVE'")
    Long countActiveSystems();
    
    @Query("SELECT COUNT(s) FROM System s WHERE s.vulnerabilityLevel IN ('HIGH', 'CRITICAL')")
    Long countHighRiskSystems();
    
    @Query("SELECT s.vulnerabilityLevel, COUNT(s) FROM System s GROUP BY s.vulnerabilityLevel")
    List<Object[]> countByVulnerabilityLevel();
    
    @Query("SELECT s FROM System s WHERE " +
           "(:status IS NULL OR s.status = :status) AND " +
           "(:vulnerabilityLevel IS NULL OR s.vulnerabilityLevel = :vulnerabilityLevel) AND " +
           "(:search IS NULL OR " +
           "LOWER(s.systemName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(s.owner) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(s.ipAddress) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<System> searchSystems(
            @Param("status") SystemStatus status,
            @Param("vulnerabilityLevel") VulnerabilityLevel vulnerabilityLevel,
            @Param("search") String search,
            Pageable pageable);
}
