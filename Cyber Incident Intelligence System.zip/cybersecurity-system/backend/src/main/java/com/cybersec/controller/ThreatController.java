package com.cybersec.controller;

import com.cybersec.dto.ApiResponse;
import com.cybersec.dto.PageResponse;
import com.cybersec.dto.ThreatDTO;
import com.cybersec.enums.RiskLevel;
import com.cybersec.enums.ThreatStatus;
import com.cybersec.security.UserPrincipal;
import com.cybersec.service.ThreatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/threats")
@RequiredArgsConstructor
@Tag(name = "Threats", description = "Threat management APIs")
@SecurityRequirement(name = "bearerAuth")
public class ThreatController {

    private final ThreatService threatService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get all threats", description = "Retrieve paginated list of all threats")
    public ResponseEntity<ApiResponse<PageResponse<ThreatDTO>>> getAllThreats(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "detectedAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        Page<ThreatDTO> threats = threatService.getAllThreats(page, size, sortBy, direction);
        PageResponse<ThreatDTO> response = PageResponse.<ThreatDTO>builder()
                .content(threats.getContent())
                .pageNumber(threats.getNumber())
                .pageSize(threats.getSize())
                .totalElements(threats.getTotalElements())
                .totalPages(threats.getTotalPages())
                .first(threats.isFirst())
                .last(threats.isLast())
                .empty(threats.isEmpty())
                .build();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get threat by ID", description = "Retrieve threat details by ID")
    public ResponseEntity<ApiResponse<ThreatDTO>> getThreatById(@PathVariable Long id) {
        ThreatDTO threat = threatService.getThreatById(id);
        return ResponseEntity.ok(ApiResponse.success(threat));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Create threat", description = "Create a new threat")
    public ResponseEntity<ApiResponse<ThreatDTO>> createThreat(
            @Valid @RequestBody ThreatDTO threatDTO,
            @AuthenticationPrincipal UserPrincipal currentUser) {
        ThreatDTO threat = threatService.createThreat(threatDTO, currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("Threat created successfully", threat));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Update threat", description = "Update threat details")
    public ResponseEntity<ApiResponse<ThreatDTO>> updateThreat(
            @PathVariable Long id,
            @Valid @RequestBody ThreatDTO threatDTO) {
        ThreatDTO threat = threatService.updateThreat(id, threatDTO);
        return ResponseEntity.ok(ApiResponse.success("Threat updated successfully", threat));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Update threat status", description = "Update threat status")
    public ResponseEntity<ApiResponse<ThreatDTO>> updateThreatStatus(
            @PathVariable Long id,
            @RequestParam ThreatStatus status) {
        ThreatDTO threat = threatService.updateThreatStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Status updated successfully", threat));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete threat", description = "Delete a threat (Admin only)")
    public ResponseEntity<ApiResponse<Void>> deleteThreat(@PathVariable Long id) {
        threatService.deleteThreat(id);
        return ResponseEntity.ok(ApiResponse.success("Threat deleted successfully", null));
    }

    @GetMapping("/search")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Search threats", description = "Search and filter threats")
    public ResponseEntity<ApiResponse<PageResponse<ThreatDTO>>> searchThreats(
            @RequestParam(required = false) ThreatStatus status,
            @RequestParam(required = false) RiskLevel riskLevel,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<ThreatDTO> threats = threatService.searchThreats(status, riskLevel, search, page, size);
        PageResponse<ThreatDTO> response = PageResponse.<ThreatDTO>builder()
                .content(threats.getContent())
                .pageNumber(threats.getNumber())
                .pageSize(threats.getSize())
                .totalElements(threats.getTotalElements())
                .totalPages(threats.getTotalPages())
                .first(threats.isFirst())
                .last(threats.isLast())
                .empty(threats.isEmpty())
                .build();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get active threats", description = "Retrieve all active threats")
    public ResponseEntity<ApiResponse<List<ThreatDTO>>> getActiveThreats() {
        List<ThreatDTO> threats = threatService.getActiveThreats();
        return ResponseEntity.ok(ApiResponse.success(threats));
    }

    @GetMapping("/recent")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get recent threats", description = "Retrieve recent threats")
    public ResponseEntity<ApiResponse<List<ThreatDTO>>> getRecentThreats(
            @RequestParam(defaultValue = "5") int limit) {
        List<ThreatDTO> threats = threatService.getRecentThreats(limit);
        return ResponseEntity.ok(ApiResponse.success(threats));
    }

    @GetMapping("/stats/by-risk")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Threat stats by risk", description = "Get threat count by risk level")
    public ResponseEntity<ApiResponse<Map<String, Long>>> getStatsByRiskLevel() {
        Map<String, Long> stats = threatService.getThreatStatsByRiskLevel();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}
