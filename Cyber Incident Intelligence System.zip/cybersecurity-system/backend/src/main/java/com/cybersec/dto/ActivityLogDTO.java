package com.cybersec.dto;

import com.cybersec.enums.EntityType;
import com.cybersec.enums.LogSeverity;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ActivityLogDTO {
    
    private Long id;
    private Long userId;
    private String userName;
    private String action;
    private EntityType entityType;
    private Long entityId;
    private String description;
    private String ipAddress;
    private LogSeverity severity;
    private LocalDateTime timestamp;
}
