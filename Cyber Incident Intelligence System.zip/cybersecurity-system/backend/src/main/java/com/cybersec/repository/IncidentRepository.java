package com.cybersec.repository;

import com.cybersec.entity.Incident;
import com.cybersec.enums.IncidentSeverity;
import com.cybersec.enums.IncidentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, Long> {
    
    Optional<Incident> findByIncidentNumber(String incidentNumber);
    
    List<Incident> findByStatus(IncidentStatus status);
    
    List<Incident> findBySeverity(IncidentSeverity severity);
    
    List<Incident> findByAssignedTo(Long assignedTo);
    
    @Query("SELECT i FROM Incident i WHERE i.status IN ('OPEN', 'IN_PROGRESS')")
    List<Incident> findOpenIncidents();
    
    @Query("SELECT COUNT(i) FROM Incident i WHERE i.status IN ('OPEN', 'IN_PROGRESS')")
    Long countOpenIncidents();
    
    @Query("SELECT COUNT(i) FROM Incident i WHERE i.severity = 'CRITICAL' AND i.status IN ('OPEN', 'IN_PROGRESS')")
    Long countCriticalIncidents();
    
    @Query("SELECT COUNT(i) FROM Incident i WHERE DATE(i.detectedAt) = CURRENT_DATE")
    Long countIncidentsToday();
    
    @Query("SELECT i.severity, COUNT(i) FROM Incident i GROUP BY i.severity")
    List<Object[]> countBySeverity();
    
    @Query("SELECT i.status, COUNT(i) FROM Incident i GROUP BY i.status")
    List<Object[]> countByStatus();
    
    @Query("SELECT i FROM Incident i WHERE " +
           "(:status IS NULL OR i.status = :status) AND " +
           "(:severity IS NULL OR i.severity = :severity) AND " +
           "(:assignedTo IS NULL OR i.assignedTo = :assignedTo) AND " +
           "(:search IS NULL OR " +
           "LOWER(i.title) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(i.description) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(i.incidentNumber) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Incident> searchIncidents(
            @Param("status") IncidentStatus status,
            @Param("severity") IncidentSeverity severity,
            @Param("assignedTo") Long assignedTo,
            @Param("search") String search,
            Pageable pageable);
    
    @Query("SELECT i FROM Incident i ORDER BY i.detectedAt DESC")
    List<Incident> findRecentIncidents(Pageable pageable);
    
    @Query("SELECT i FROM Incident i WHERE i.detectedAt BETWEEN :startDate AND :endDate")
    List<Incident> findByDateRange(@Param("startDate") LocalDateTime startDate, 
                                   @Param("endDate") LocalDateTime endDate);
}
