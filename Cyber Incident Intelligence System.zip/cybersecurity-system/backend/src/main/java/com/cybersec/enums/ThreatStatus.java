package com.cybersec.enums;

public enum ThreatStatus {
    ACTIVE,
    INVESTIGATING,
    CONTAINED,
    RESOLVED,
    FALSE_POSITIVE
}
