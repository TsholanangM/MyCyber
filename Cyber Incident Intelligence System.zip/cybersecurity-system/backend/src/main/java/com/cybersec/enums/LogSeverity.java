package com.cybersec.enums;

public enum LogSeverity {
    INFO,
    WARNING,
    ERROR,
    CRITICAL
}
