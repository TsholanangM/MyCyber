package com.cybersec.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDTO {
    
    private Long openIncidents;
    private Long criticalIncidents;
    private Long activeThreats;
    private Long activeSystems;
    private Long highRiskSystems;
    private Long incidentsToday;
    private Long logs24h;
    
    private Map<String, Long> incidentsBySeverity;
    private Map<String, Long> incidentsByStatus;
    private Map<String, Long> systemsByVulnerability;
    private Map<String, Long> threatsByRiskLevel;
    
    private List<IncidentDTO> recentIncidents;
    private List<ThreatDTO> recentThreats;
    private List<ActivityLogDTO> recentActivities;
}
