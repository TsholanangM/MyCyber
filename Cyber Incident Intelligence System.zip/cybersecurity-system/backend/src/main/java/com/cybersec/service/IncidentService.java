package com.cybersec.service;

import com.cybersec.dto.IncidentDTO;
import com.cybersec.entity.Incident;
import com.cybersec.enums.IncidentSeverity;
import com.cybersec.enums.IncidentStatus;
import com.cybersec.exception.ResourceNotFoundException;
import com.cybersec.repository.IncidentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class IncidentService {

    private final IncidentRepository incidentRepository;
    private final LogService logService;

    private static final DateTimeFormatter INCIDENT_NUMBER_FORMATTER = 
            DateTimeFormatter.ofPattern("'INC'-yyyy-'0000'");

    @Transactional(readOnly = true)
    public List<IncidentDTO> getAllIncidents() {
        return incidentRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<IncidentDTO> getAllIncidents(int page, int size, String sortBy, String direction) {
        Sort sort = direction.equalsIgnoreCase("desc") 
                ? Sort.by(sortBy).descending() 
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return incidentRepository.findAll(pageable).map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public IncidentDTO getIncidentById(Long id) {
        Incident incident = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident", "id", id));
        return convertToDTO(incident);
    }

    @Transactional(readOnly = true)
    public IncidentDTO getIncidentByNumber(String incidentNumber) {
        Incident incident = incidentRepository.findByIncidentNumber(incidentNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Incident", "number", incidentNumber));
        return convertToDTO(incident);
    }

    @Transactional
    public IncidentDTO createIncident(IncidentDTO incidentDTO, Long reportedBy) {
        Incident incident = new Incident();
        incident.setIncidentNumber(generateIncidentNumber());
        incident.setTitle(incidentDTO.getTitle());
        incident.setDescription(incidentDTO.getDescription());
        incident.setSeverity(incidentDTO.getSeverity());
        incident.setStatus(IncidentStatus.OPEN);
        incident.setIncidentType(incidentDTO.getIncidentType());
        incident.setAttackTypeId(incidentDTO.getAttackTypeId());
        incident.setAffectedSystemId(incidentDTO.getAffectedSystemId());
        incident.setReportedBy(reportedBy);
        incident.setAssignedTo(incidentDTO.getAssignedTo());
        incident.setThreatId(incidentDTO.getThreatId());
        incident.setRootCause(incidentDTO.getRootCause());
        incident.setImpactAssessment(incidentDTO.getImpactAssessment());
        incident.setDetectedAt(incidentDTO.getDetectedAt());
        incident.setReportedAt(LocalDateTime.now());
        incident.setEstimatedLoss(incidentDTO.getEstimatedLoss());

        Incident savedIncident = incidentRepository.save(incident);
        
        logService.logIncidentAction("INCIDENT_CREATED", savedIncident.getId(), 
                "Created incident: " + savedIncident.getIncidentNumber());

        return convertToDTO(savedIncident);
    }

    @Transactional
    public IncidentDTO updateIncident(Long id, IncidentDTO incidentDTO) {
        Incident incident = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident", "id", id));

        incident.setTitle(incidentDTO.getTitle());
        incident.setDescription(incidentDTO.getDescription());
        incident.setSeverity(incidentDTO.getSeverity());
        incident.setIncidentType(incidentDTO.getIncidentType());
        incident.setAttackTypeId(incidentDTO.getAttackTypeId());
        incident.setAffectedSystemId(incidentDTO.getAffectedSystemId());
        incident.setAssignedTo(incidentDTO.getAssignedTo());
        incident.setThreatId(incidentDTO.getThreatId());
        incident.setRootCause(incidentDTO.getRootCause());
        incident.setImpactAssessment(incidentDTO.getImpactAssessment());
        incident.setResolutionNotes(incidentDTO.getResolutionNotes());
        incident.setEstimatedLoss(incidentDTO.getEstimatedLoss());

        Incident updatedIncident = incidentRepository.save(incident);
        
        logService.logIncidentAction("INCIDENT_UPDATED", updatedIncident.getId(), 
                "Updated incident: " + updatedIncident.getIncidentNumber());

        return convertToDTO(updatedIncident);
    }

    @Transactional
    public IncidentDTO updateIncidentStatus(Long id, IncidentStatus status) {
        Incident incident = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident", "id", id));

        IncidentStatus oldStatus = incident.getStatus();
        incident.setStatus(status);
        
        if (status == IncidentStatus.RESOLVED) {
            incident.setResolvedAt(LocalDateTime.now());
        } else if (status == IncidentStatus.CLOSED) {
            incident.setClosedAt(LocalDateTime.now());
        }

        Incident updatedIncident = incidentRepository.save(incident);
        
        logService.logIncidentAction("STATUS_CHANGED", updatedIncident.getId(), 
                String.format("Status changed from %s to %s for incident: %s", 
                        oldStatus, status, updatedIncident.getIncidentNumber()));

        return convertToDTO(updatedIncident);
    }

    @Transactional
    public void deleteIncident(Long id) {
        Incident incident = incidentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Incident", "id", id));
        
        incidentRepository.delete(incident);
        
        logService.logIncidentAction("INCIDENT_DELETED", id, 
                "Deleted incident: " + incident.getIncidentNumber());
    }

    @Transactional(readOnly = true)
    public Page<IncidentDTO> searchIncidents(IncidentStatus status, IncidentSeverity severity, 
                                              Long assignedTo, String search, 
                                              int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("detectedAt").descending());
        return incidentRepository.searchIncidents(status, severity, assignedTo, search, pageable)
                .map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public List<IncidentDTO> getRecentIncidents(int limit) {
        return incidentRepository.findRecentIncidents(PageRequest.of(0, limit))
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Map<String, Long> getIncidentStatsBySeverity() {
        List<Object[]> results = incidentRepository.countBySeverity();
        return results.stream()
                .collect(Collectors.toMap(
                        row -> row[0].toString(),
                        row -> (Long) row[1]
                ));
    }

    @Transactional(readOnly = true)
    public Map<String, Long> getIncidentStatsByStatus() {
        List<Object[]> results = incidentRepository.countByStatus();
        return results.stream()
                .collect(Collectors.toMap(
                        row -> row[0].toString(),
                        row -> (Long) row[1]
                ));
    }

    private String generateIncidentNumber() {
        String year = String.valueOf(LocalDateTime.now().getYear());
        long count = incidentRepository.count() + 1;
        return String.format("INC-%s-%04d", year, count);
    }

    private IncidentDTO convertToDTO(Incident incident) {
        IncidentDTO dto = new IncidentDTO();
        dto.setId(incident.getId());
        dto.setIncidentNumber(incident.getIncidentNumber());
        dto.setTitle(incident.getTitle());
        dto.setDescription(incident.getDescription());
        dto.setSeverity(incident.getSeverity());
        dto.setStatus(incident.getStatus());
        dto.setIncidentType(incident.getIncidentType());
        dto.setAttackTypeId(incident.getAttackTypeId());
        if (incident.getAttackType() != null) {
            dto.setAttackTypeName(incident.getAttackType().getName());
        }
        dto.setAffectedSystemId(incident.getAffectedSystemId());
        if (incident.getAffectedSystem() != null) {
            dto.setAffectedSystemName(incident.getAffectedSystem().getSystemName());
        }
        dto.setReportedBy(incident.getReportedBy());
        if (incident.getReportedByUser() != null) {
            dto.setReportedByName(incident.getReportedByUser().getName());
        }
        dto.setAssignedTo(incident.getAssignedTo());
        if (incident.getAssignedToUser() != null) {
            dto.setAssignedToName(incident.getAssignedToUser().getName());
        }
        dto.setThreatId(incident.getThreatId());
        dto.setRootCause(incident.getRootCause());
        dto.setImpactAssessment(incident.getImpactAssessment());
        dto.setResolutionNotes(incident.getResolutionNotes());
        dto.setDetectedAt(incident.getDetectedAt());
        dto.setReportedAt(incident.getReportedAt());
        dto.setResolvedAt(incident.getResolvedAt());
        dto.setClosedAt(incident.getClosedAt());
        dto.setSlaBreach(incident.getSlaBreach());
        dto.setEstimatedLoss(incident.getEstimatedLoss());
        dto.setCreatedAt(incident.getCreatedAt());
        dto.setUpdatedAt(incident.getUpdatedAt());
        return dto;
    }
}
