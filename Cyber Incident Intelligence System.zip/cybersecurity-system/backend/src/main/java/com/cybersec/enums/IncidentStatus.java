package com.cybersec.enums;

public enum IncidentStatus {
    OPEN,
    IN_PROGRESS,
    PENDING,
    RESOLVED,
    CLOSED
}
