package com.cybersec.entity;

import com.cybersec.enums.IncidentSeverity;
import com.cybersec.enums.IncidentStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "incidents", indexes = {
    @Index(name = "idx_incident_number", columnList = "incidentNumber"),
    @Index(name = "idx_severity", columnList = "severity"),
    @Index(name = "idx_status", columnList = "status"),
    @Index(name = "idx_detected_at", columnList = "detectedAt"),
    @Index(name = "idx_reported_at", columnList = "reportedAt"),
    @Index(name = "idx_assigned_to", columnList = "assignedTo"),
    @Index(name = "idx_attack_type", columnList = "attackTypeId")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Incident {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "incident_number", nullable = false, unique = true, length = 50)
    private String incidentNumber;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private IncidentSeverity severity;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private IncidentStatus status = IncidentStatus.OPEN;

    @Column(name = "incident_type", length = 100)
    private String incidentType;

    @Column(name = "attack_type_id")
    private Long attackTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attack_type_id", insertable = false, updatable = false)
    private AttackType attackType;

    @Column(name = "affected_system_id")
    private Long affectedSystemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "affected_system_id", insertable = false, updatable = false)
    private System affectedSystem;

    @Column(name = "reported_by", nullable = false)
    private Long reportedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reported_by", insertable = false, updatable = false)
    private User reportedByUser;

    @Column(name = "assigned_to")
    private Long assignedTo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_to", insertable = false, updatable = false)
    private User assignedToUser;

    @Column(name = "threat_id")
    private Long threatId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "threat_id", insertable = false, updatable = false)
    private Threat threat;

    @Column(name = "root_cause", columnDefinition = "TEXT")
    private String rootCause;

    @Column(name = "impact_assessment", columnDefinition = "TEXT")
    private String impactAssessment;

    @Column(name = "resolution_notes", columnDefinition = "TEXT")
    private String resolutionNotes;

    @Column(name = "detected_at", nullable = false)
    private LocalDateTime detectedAt;

    @Column(name = "reported_at")
    private LocalDateTime reportedAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @Column(name = "closed_at")
    private LocalDateTime closedAt;

    @Column(name = "sla_breach")
    private Boolean slaBreach = false;

    @Column(name = "estimated_loss", precision = 15, scale = 2)
    private BigDecimal estimatedLoss;

    @CreatedDate
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
