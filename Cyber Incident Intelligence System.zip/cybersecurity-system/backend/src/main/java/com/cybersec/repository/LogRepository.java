package com.cybersec.repository;

import com.cybersec.entity.Log;
import com.cybersec.enums.EntityType;
import com.cybersec.enums.LogSeverity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface LogRepository extends JpaRepository<Log, Long> {
    
    List<Log> findByUserId(Long userId);
    
    List<Log> findByEntityTypeAndEntityId(EntityType entityType, Long entityId);
    
    @Query("SELECT COUNT(l) FROM Log l WHERE l.timestamp >= :since")
    Long countSince(@Param("since") LocalDateTime since);
    
    @Query("SELECT l FROM Log l ORDER BY l.timestamp DESC")
    List<Log> findRecentLogs(Pageable pageable);
    
    @Query("SELECT l FROM Log l WHERE " +
           "(:userId IS NULL OR l.userId = :userId) AND " +
           "(:action IS NULL OR l.action = :action) AND " +
           "(:severity IS NULL OR l.severity = :severity) AND " +
           "(:startDate IS NULL OR l.timestamp >= :startDate) AND " +
           "(:endDate IS NULL OR l.timestamp <= :endDate)")
    Page<Log> searchLogs(
            @Param("userId") Long userId,
            @Param("action") String action,
            @Param("severity") LogSeverity severity,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate,
            Pageable pageable);
}
