package com.cybersec.dto;

import com.cybersec.enums.IncidentSeverity;
import com.cybersec.enums.IncidentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class IncidentDTO {
    
    private Long id;
    private String incidentNumber;
    
    @NotBlank(message = "Title is required")
    private String title;
    
    @NotBlank(message = "Description is required")
    private String description;
    
    @NotNull(message = "Severity is required")
    private IncidentSeverity severity;
    
    private IncidentStatus status;
    private String incidentType;
    private Long attackTypeId;
    private String attackTypeName;
    private Long affectedSystemId;
    private String affectedSystemName;
    private Long reportedBy;
    private String reportedByName;
    private Long assignedTo;
    private String assignedToName;
    private Long threatId;
    private String rootCause;
    private String impactAssessment;
    private String resolutionNotes;
    
    @NotNull(message = "Detected at is required")
    private LocalDateTime detectedAt;
    
    private LocalDateTime reportedAt;
    private LocalDateTime resolvedAt;
    private LocalDateTime closedAt;
    private Boolean slaBreach;
    private BigDecimal estimatedLoss;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
