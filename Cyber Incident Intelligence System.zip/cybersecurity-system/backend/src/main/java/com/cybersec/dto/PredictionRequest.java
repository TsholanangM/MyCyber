package com.cybersec.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.Map;

@Data
public class PredictionRequest {
    
    @NotBlank(message = "Prediction type is required")
    private String predictionType;
    
    @NotBlank(message = "Entity type is required")
    private String entityType;
    
    @NotNull(message = "Entity ID is required")
    private Long entityId;
    
    private Map<String, Object> features;
}
