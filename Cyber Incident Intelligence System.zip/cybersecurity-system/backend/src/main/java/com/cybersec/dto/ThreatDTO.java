package com.cybersec.dto;

import com.cybersec.enums.RiskLevel;
import com.cybersec.enums.ThreatStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ThreatDTO {
    
    private Long id;
    
    @NotBlank(message = "Threat name is required")
    private String threatName;
    
    @NotBlank(message = "Type is required")
    private String type;
    
    @NotNull(message = "Risk level is required")
    private RiskLevel riskLevel;
    
    private String description;
    private Long attackTypeId;
    private String attackTypeName;
    private Long affectedSystemId;
    private String affectedSystemName;
    private String sourceIp;
    private String targetIp;
    private String indicatorsOfCompromise;
    private String mitigationStrategy;
    private LocalDateTime detectedAt;
    private LocalDateTime resolvedAt;
    private ThreatStatus status;
    private Long detectedBy;
    private String detectedByName;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
