package com.cybersec.entity;

import com.cybersec.enums.SystemStatus;
import com.cybersec.enums.SystemType;
import com.cybersec.enums.VulnerabilityLevel;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "systems", indexes = {
    @Index(name = "idx_system_name", columnList = "systemName"),
    @Index(name = "idx_vulnerability", columnList = "vulnerabilityLevel"),
    @Index(name = "idx_status", columnList = "status"),
    @Index(name = "idx_owner", columnList = "owner")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class System {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "system_name", nullable = false, length = 150)
    private String systemName;

    @Column(nullable = false, length = 100)
    private String owner;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "ip_address", length = 45)
    private String ipAddress;

    @Enumerated(EnumType.STRING)
    @Column(name = "vulnerability_level", nullable = false, length = 20)
    private VulnerabilityLevel vulnerabilityLevel = VulnerabilityLevel.LOW;

    @Enumerated(EnumType.STRING)
    @Column(name = "system_type", nullable = false, length = 30)
    private SystemType systemType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private SystemStatus status = SystemStatus.ACTIVE;

    @Column(length = 100)
    private String location;

    @CreatedDate
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
