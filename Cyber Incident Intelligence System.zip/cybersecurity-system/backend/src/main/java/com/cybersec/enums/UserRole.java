package com.cybersec.enums;

public enum UserRole {
    ADMIN,
    ANALYST,
    USER
}
