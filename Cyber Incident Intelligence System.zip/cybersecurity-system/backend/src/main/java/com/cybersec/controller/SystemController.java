package com.cybersec.controller;

import com.cybersec.dto.ApiResponse;
import com.cybersec.dto.PageResponse;
import com.cybersec.dto.SystemDTO;
import com.cybersec.enums.SystemStatus;
import com.cybersec.enums.VulnerabilityLevel;
import com.cybersec.service.SystemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/systems")
@RequiredArgsConstructor
@Tag(name = "Systems", description = "System management APIs")
@SecurityRequirement(name = "bearerAuth")
public class SystemController {

    private final SystemService systemService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get all systems", description = "Retrieve paginated list of all systems")
    public ResponseEntity<ApiResponse<PageResponse<SystemDTO>>> getAllSystems(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "systemName") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        Page<SystemDTO> systems = systemService.getAllSystems(page, size, sortBy, direction);
        PageResponse<SystemDTO> response = PageResponse.<SystemDTO>builder()
                .content(systems.getContent())
                .pageNumber(systems.getNumber())
                .pageSize(systems.getSize())
                .totalElements(systems.getTotalElements())
                .totalPages(systems.getTotalPages())
                .first(systems.isFirst())
                .last(systems.isLast())
                .empty(systems.isEmpty())
                .build();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get system by ID", description = "Retrieve system details by ID")
    public ResponseEntity<ApiResponse<SystemDTO>> getSystemById(@PathVariable Long id) {
        SystemDTO system = systemService.getSystemById(id);
        return ResponseEntity.ok(ApiResponse.success(system));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Create system", description = "Create a new system")
    public ResponseEntity<ApiResponse<SystemDTO>> createSystem(@Valid @RequestBody SystemDTO systemDTO) {
        SystemDTO system = systemService.createSystem(systemDTO);
        return ResponseEntity.ok(ApiResponse.success("System created successfully", system));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Update system", description = "Update system details")
    public ResponseEntity<ApiResponse<SystemDTO>> updateSystem(
            @PathVariable Long id,
            @Valid @RequestBody SystemDTO systemDTO) {
        SystemDTO system = systemService.updateSystem(id, systemDTO);
        return ResponseEntity.ok(ApiResponse.success("System updated successfully", system));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Update system status", description = "Update system status")
    public ResponseEntity<ApiResponse<SystemDTO>> updateSystemStatus(
            @PathVariable Long id,
            @RequestParam SystemStatus status) {
        SystemDTO system = systemService.updateSystemStatus(id, status);
        return ResponseEntity.ok(ApiResponse.success("Status updated successfully", system));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete system", description = "Delete a system (Admin only)")
    public ResponseEntity<ApiResponse<Void>> deleteSystem(@PathVariable Long id) {
        systemService.deleteSystem(id);
        return ResponseEntity.ok(ApiResponse.success("System deleted successfully", null));
    }

    @GetMapping("/search")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Search systems", description = "Search and filter systems")
    public ResponseEntity<ApiResponse<PageResponse<SystemDTO>>> searchSystems(
            @RequestParam(required = false) SystemStatus status,
            @RequestParam(required = false) VulnerabilityLevel vulnerabilityLevel,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<SystemDTO> systems = systemService.searchSystems(status, vulnerabilityLevel, search, page, size);
        PageResponse<SystemDTO> response = PageResponse.<SystemDTO>builder()
                .content(systems.getContent())
                .pageNumber(systems.getNumber())
                .pageSize(systems.getSize())
                .totalElements(systems.getTotalElements())
                .totalPages(systems.getTotalPages())
                .first(systems.isFirst())
                .last(systems.isLast())
                .empty(systems.isEmpty())
                .build();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/stats/by-vulnerability")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "System stats by vulnerability", description = "Get system count by vulnerability level")
    public ResponseEntity<ApiResponse<Map<String, Long>>> getStatsByVulnerability() {
        Map<String, Long> stats = systemService.getSystemStatsByVulnerability();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}
