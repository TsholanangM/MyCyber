package com.cybersec.entity;

import com.cybersec.enums.RiskLevel;
import com.cybersec.enums.ThreatStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "threats", indexes = {
    @Index(name = "idx_risk_level", columnList = "riskLevel"),
    @Index(name = "idx_status", columnList = "status"),
    @Index(name = "idx_detected_at", columnList = "detectedAt"),
    @Index(name = "idx_attack_type", columnList = "attackTypeId"),
    @Index(name = "idx_affected_system", columnList = "affectedSystemId")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Threat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "threat_name", nullable = false, length = 150)
    private String threatName;

    @Column(nullable = false, length = 100)
    private String type;

    @Enumerated(EnumType.STRING)
    @Column(name = "risk_level", nullable = false, length = 20)
    private RiskLevel riskLevel;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "attack_type_id")
    private Long attackTypeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attack_type_id", insertable = false, updatable = false)
    private AttackType attackType;

    @Column(name = "affected_system_id")
    private Long affectedSystemId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "affected_system_id", insertable = false, updatable = false)
    private System affectedSystem;

    @Column(name = "source_ip", length = 45)
    private String sourceIp;

    @Column(name = "target_ip", length = 45)
    private String targetIp;

    @Column(name = "indicators_of_compromise", columnDefinition = "TEXT")
    private String indicatorsOfCompromise;

    @Column(name = "mitigation_strategy", columnDefinition = "TEXT")
    private String mitigationStrategy;

    @Column(name = "detected_at")
    private LocalDateTime detectedAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private ThreatStatus status = ThreatStatus.ACTIVE;

    @Column(name = "detected_by")
    private Long detectedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "detected_by", insertable = false, updatable = false)
    private User detectedByUser;

    @CreatedDate
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
