package com.cybersec.controller;

import com.cybersec.dto.ApiResponse;
import com.cybersec.dto.PredictionResponse;
import com.cybersec.service.AIPredictionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/predictions")
@RequiredArgsConstructor
@Tag(name = "AI Predictions", description = "AI-powered prediction APIs")
@SecurityRequirement(name = "bearerAuth")
public class AIPredictionController {

    private final AIPredictionService aiPredictionService;

    @GetMapping("/attack-likelihood/{systemId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Predict attack likelihood", description = "Get AI prediction for attack likelihood on a system")
    public ResponseEntity<ApiResponse<PredictionResponse>> predictAttackLikelihood(@PathVariable Long systemId) {
        PredictionResponse prediction = aiPredictionService.predictAttackLikelihood(systemId);
        return ResponseEntity.ok(ApiResponse.success(prediction));
    }

    @PostMapping("/incident-severity/{incidentId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Classify incident severity", description = "Get AI classification for incident severity")
    public ResponseEntity<ApiResponse<PredictionResponse>> classifyIncidentSeverity(
            @PathVariable Long incidentId,
            @RequestBody Map<String, Object> features) {
        PredictionResponse prediction = aiPredictionService.classifyIncidentSeverity(incidentId, features);
        return ResponseEntity.ok(ApiResponse.success(prediction));
    }

    @GetMapping("/risk-score/{systemId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Calculate risk score", description = "Get AI-calculated risk score for a system")
    public ResponseEntity<ApiResponse<PredictionResponse>> calculateRiskScore(@PathVariable Long systemId) {
        PredictionResponse prediction = aiPredictionService.calculateRiskScore(systemId);
        return ResponseEntity.ok(ApiResponse.success(prediction));
    }

    @PostMapping("/detect-anomaly")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Detect anomaly", description = "Detect anomalies in system metrics")
    public ResponseEntity<ApiResponse<PredictionResponse>> detectAnomaly(@RequestBody Map<String, Object> metrics) {
        PredictionResponse prediction = aiPredictionService.detectAnomaly(metrics);
        return ResponseEntity.ok(ApiResponse.success(prediction));
    }

    @GetMapping("/model-status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Get model status", description = "Get AI model status and health")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getModelStatus() {
        Map<String, Object> status = aiPredictionService.getModelStatus();
        return ResponseEntity.ok(ApiResponse.success(status));
    }
}
