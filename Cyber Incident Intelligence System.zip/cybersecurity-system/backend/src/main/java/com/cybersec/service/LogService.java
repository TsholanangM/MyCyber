package com.cybersec.service;

import com.cybersec.dto.ActivityLogDTO;
import com.cybersec.entity.Log;
import com.cybersec.enums.EntityType;
import com.cybersec.enums.LogSeverity;
import com.cybersec.repository.LogRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class LogService {

    private final LogRepository logRepository;
    private final ObjectMapper objectMapper;

    @Transactional
    public void logAction(String action, EntityType entityType, Long entityId, 
                          String description, LogSeverity severity, Map<String, Object> metadata) {
        try {
            Long userId = getCurrentUserId();
            
            Log activityLog = Log.builder()
                    .userId(userId)
                    .action(action)
                    .entityType(entityType)
                    .entityId(entityId)
                    .description(description)
                    .severity(severity)
                    .metadata(metadata != null ? objectMapper.writeValueAsString(metadata) : null)
                    .timestamp(LocalDateTime.now())
                    .build();
            
            logRepository.save(activityLog);
        } catch (Exception e) {
            log.error("Failed to log action: {}", e.getMessage());
        }
    }

    @Transactional
    public void logUserAction(String action, Long userId, String description) {
        logAction(action, EntityType.USER, userId, description, LogSeverity.INFO, null);
    }

    @Transactional
    public void logIncidentAction(String action, Long incidentId, String description) {
        logAction(action, EntityType.INCIDENT, incidentId, description, LogSeverity.INFO, null);
    }

    @Transactional
    public void logThreatAction(String action, Long threatId, String description) {
        logAction(action, EntityType.THREAT, threatId, description, LogSeverity.INFO, null);
    }

    @Transactional
    public void logSystemAction(String action, Long systemId, String description) {
        logAction(action, EntityType.SYSTEM, systemId, description, LogSeverity.INFO, null);
    }

    @Transactional
    public void logError(String action, String description, Map<String, Object> metadata) {
        logAction(action, EntityType.SYSTEM, null, description, LogSeverity.ERROR, metadata);
    }

    @Transactional(readOnly = true)
    public List<ActivityLogDTO> getAllLogs() {
        return logRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<ActivityLogDTO> getAllLogs(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("timestamp").descending());
        return logRepository.findAll(pageable).map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public List<ActivityLogDTO> getRecentLogs(int limit) {
        return logRepository.findRecentLogs(PageRequest.of(0, limit))
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ActivityLogDTO> getLogsByUser(Long userId) {
        return logRepository.findByUserId(userId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ActivityLogDTO> getLogsByEntity(EntityType entityType, Long entityId) {
        return logRepository.findByEntityTypeAndEntityId(entityType, entityId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Long getLogCountSince(LocalDateTime since) {
        return logRepository.countSince(since);
    }

    private Long getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof com.cybersec.security.UserPrincipal) {
            com.cybersec.security.UserPrincipal userPrincipal = 
                    (com.cybersec.security.UserPrincipal) authentication.getPrincipal();
            return userPrincipal.getId();
        }
        return null;
    }

    private ActivityLogDTO convertToDTO(Log log) {
        ActivityLogDTO dto = new ActivityLogDTO();
        dto.setId(log.getId());
        dto.setUserId(log.getUserId());
        if (log.getUser() != null) {
            dto.setUserName(log.getUser().getName());
        }
        dto.setAction(log.getAction());
        dto.setEntityType(log.getEntityType());
        dto.setEntityId(log.getEntityId());
        dto.setDescription(log.getDescription());
        dto.setIpAddress(log.getIpAddress());
        dto.setSeverity(log.getSeverity());
        dto.setTimestamp(log.getTimestamp());
        return dto;
    }
}
