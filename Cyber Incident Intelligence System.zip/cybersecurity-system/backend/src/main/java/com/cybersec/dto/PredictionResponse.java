package com.cybersec.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PredictionResponse {
    
    private String predictionType;
    private String entityType;
    private Long entityId;
    private String predictionValue;
    private Double confidenceScore;
    private String modelVersion;
    private Map<String, Object> featuresUsed;
    private Map<String, Object> additionalData;
    private LocalDateTime predictedAt;
}
