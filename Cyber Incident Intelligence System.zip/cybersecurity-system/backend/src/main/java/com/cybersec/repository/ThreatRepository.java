package com.cybersec.repository;

import com.cybersec.entity.Threat;
import com.cybersec.enums.RiskLevel;
import com.cybersec.enums.ThreatStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ThreatRepository extends JpaRepository<Threat, Long> {
    
    List<Threat> findByStatus(ThreatStatus status);
    
    List<Threat> findByRiskLevel(RiskLevel riskLevel);
    
    @Query("SELECT t FROM Threat t WHERE t.status = 'ACTIVE'")
    List<Threat> findActiveThreats();
    
    @Query("SELECT COUNT(t) FROM Threat t WHERE t.status = 'ACTIVE'")
    Long countActiveThreats();
    
    @Query("SELECT t.riskLevel, COUNT(t) FROM Threat t GROUP BY t.riskLevel")
    List<Object[]> countByRiskLevel();
    
    @Query("SELECT t FROM Threat t WHERE " +
           "(:status IS NULL OR t.status = :status) AND " +
           "(:riskLevel IS NULL OR t.riskLevel = :riskLevel) AND " +
           "(:search IS NULL OR " +
           "LOWER(t.threatName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(t.description) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(t.type) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Threat> searchThreats(
            @Param("status") ThreatStatus status,
            @Param("riskLevel") RiskLevel riskLevel,
            @Param("search") String search,
            Pageable pageable);
    
    @Query("SELECT t FROM Threat t ORDER BY t.detectedAt DESC")
    List<Threat> findRecentThreats(Pageable pageable);
}
