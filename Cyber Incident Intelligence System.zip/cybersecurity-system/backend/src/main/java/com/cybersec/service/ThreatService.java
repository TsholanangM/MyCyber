package com.cybersec.service;

import com.cybersec.dto.ThreatDTO;
import com.cybersec.entity.Threat;
import com.cybersec.enums.RiskLevel;
import com.cybersec.enums.ThreatStatus;
import com.cybersec.exception.ResourceNotFoundException;
import com.cybersec.repository.ThreatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ThreatService {

    private final ThreatRepository threatRepository;
    private final LogService logService;

    @Transactional(readOnly = true)
    public List<ThreatDTO> getAllThreats() {
        return threatRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<ThreatDTO> getAllThreats(int page, int size, String sortBy, String direction) {
        Sort sort = direction.equalsIgnoreCase("desc") 
                ? Sort.by(sortBy).descending() 
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return threatRepository.findAll(pageable).map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public ThreatDTO getThreatById(Long id) {
        Threat threat = threatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Threat", "id", id));
        return convertToDTO(threat);
    }

    @Transactional
    public ThreatDTO createThreat(ThreatDTO threatDTO, Long detectedBy) {
        Threat threat = new Threat();
        threat.setThreatName(threatDTO.getThreatName());
        threat.setType(threatDTO.getType());
        threat.setRiskLevel(threatDTO.getRiskLevel());
        threat.setDescription(threatDTO.getDescription());
        threat.setAttackTypeId(threatDTO.getAttackTypeId());
        threat.setAffectedSystemId(threatDTO.getAffectedSystemId());
        threat.setSourceIp(threatDTO.getSourceIp());
        threat.setTargetIp(threatDTO.getTargetIp());
        threat.setIndicatorsOfCompromise(threatDTO.getIndicatorsOfCompromise());
        threat.setMitigationStrategy(threatDTO.getMitigationStrategy());
        threat.setDetectedAt(LocalDateTime.now());
        threat.setStatus(ThreatStatus.ACTIVE);
        threat.setDetectedBy(detectedBy);

        Threat savedThreat = threatRepository.save(threat);
        
        logService.logThreatAction("THREAT_CREATED", savedThreat.getId(), 
                "Created threat: " + savedThreat.getThreatName());

        return convertToDTO(savedThreat);
    }

    @Transactional
    public ThreatDTO updateThreat(Long id, ThreatDTO threatDTO) {
        Threat threat = threatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Threat", "id", id));

        threat.setThreatName(threatDTO.getThreatName());
        threat.setType(threatDTO.getType());
        threat.setRiskLevel(threatDTO.getRiskLevel());
        threat.setDescription(threatDTO.getDescription());
        threat.setAttackTypeId(threatDTO.getAttackTypeId());
        threat.setAffectedSystemId(threatDTO.getAffectedSystemId());
        threat.setSourceIp(threatDTO.getSourceIp());
        threat.setTargetIp(threatDTO.getTargetIp());
        threat.setIndicatorsOfCompromise(threatDTO.getIndicatorsOfCompromise());
        threat.setMitigationStrategy(threatDTO.getMitigationStrategy());

        Threat updatedThreat = threatRepository.save(threat);
        
        logService.logThreatAction("THREAT_UPDATED", updatedThreat.getId(), 
                "Updated threat: " + updatedThreat.getThreatName());

        return convertToDTO(updatedThreat);
    }

    @Transactional
    public ThreatDTO updateThreatStatus(Long id, ThreatStatus status) {
        Threat threat = threatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Threat", "id", id));

        threat.setStatus(status);
        
        if (status == ThreatStatus.RESOLVED || status == ThreatStatus.FALSE_POSITIVE) {
            threat.setResolvedAt(LocalDateTime.now());
        }

        Threat updatedThreat = threatRepository.save(threat);
        
        logService.logThreatAction("STATUS_CHANGED", updatedThreat.getId(), 
                String.format("Threat status changed to %s: %s", status, updatedThreat.getThreatName()));

        return convertToDTO(updatedThreat);
    }

    @Transactional
    public void deleteThreat(Long id) {
        Threat threat = threatRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Threat", "id", id));
        
        threatRepository.delete(threat);
        
        logService.logThreatAction("THREAT_DELETED", id, 
                "Deleted threat: " + threat.getThreatName());
    }

    @Transactional(readOnly = true)
    public Page<ThreatDTO> searchThreats(ThreatStatus status, RiskLevel riskLevel, 
                                          String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("detectedAt").descending());
        return threatRepository.searchThreats(status, riskLevel, search, pageable)
                .map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public List<ThreatDTO> getActiveThreats() {
        return threatRepository.findActiveThreats().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ThreatDTO> getRecentThreats(int limit) {
        return threatRepository.findRecentThreats(PageRequest.of(0, limit))
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Map<String, Long> getThreatStatsByRiskLevel() {
        List<Object[]> results = threatRepository.countByRiskLevel();
        return results.stream()
                .collect(Collectors.toMap(
                        row -> row[0].toString(),
                        row -> (Long) row[1]
                ));
    }

    private ThreatDTO convertToDTO(Threat threat) {
        ThreatDTO dto = new ThreatDTO();
        dto.setId(threat.getId());
        dto.setThreatName(threat.getThreatName());
        dto.setType(threat.getType());
        dto.setRiskLevel(threat.getRiskLevel());
        dto.setDescription(threat.getDescription());
        dto.setAttackTypeId(threat.getAttackTypeId());
        if (threat.getAttackType() != null) {
            dto.setAttackTypeName(threat.getAttackType().getName());
        }
        dto.setAffectedSystemId(threat.getAffectedSystemId());
        if (threat.getAffectedSystem() != null) {
            dto.setAffectedSystemName(threat.getAffectedSystem().getSystemName());
        }
        dto.setSourceIp(threat.getSourceIp());
        dto.setTargetIp(threat.getTargetIp());
        dto.setIndicatorsOfCompromise(threat.getIndicatorsOfCompromise());
        dto.setMitigationStrategy(threat.getMitigationStrategy());
        dto.setDetectedAt(threat.getDetectedAt());
        dto.setResolvedAt(threat.getResolvedAt());
        dto.setStatus(threat.getStatus());
        dto.setDetectedBy(threat.getDetectedBy());
        if (threat.getDetectedByUser() != null) {
            dto.setDetectedByName(threat.getDetectedByUser().getName());
        }
        dto.setCreatedAt(threat.getCreatedAt());
        dto.setUpdatedAt(threat.getUpdatedAt());
        return dto;
    }
}
