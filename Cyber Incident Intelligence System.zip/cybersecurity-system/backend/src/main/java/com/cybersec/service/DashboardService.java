package com.cybersec.service;

import com.cybersec.dto.DashboardStatsDTO;
import com.cybersec.dto.IncidentDTO;
import com.cybersec.dto.ThreatDTO;
import com.cybersec.dto.ActivityLogDTO;
import com.cybersec.repository.IncidentRepository;
import com.cybersec.repository.SystemRepository;
import com.cybersec.repository.ThreatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DashboardService {

    private final IncidentRepository incidentRepository;
    private final ThreatRepository threatRepository;
    private final SystemRepository systemRepository;
    private final IncidentService incidentService;
    private final ThreatService threatService;
    private final LogService logService;

    @Transactional(readOnly = true)
    public DashboardStatsDTO getDashboardStats() {
        DashboardStatsDTO stats = new DashboardStatsDTO();
        
        // Count statistics
        stats.setOpenIncidents(incidentRepository.countOpenIncidents());
        stats.setCriticalIncidents(incidentRepository.countCriticalIncidents());
        stats.setActiveThreats(threatRepository.countActiveThreats());
        stats.setActiveSystems(systemRepository.countActiveSystems());
        stats.setHighRiskSystems(systemRepository.countHighRiskSystems());
        stats.setIncidentsToday(incidentRepository.countIncidentsToday());
        stats.setLogs24h(logService.getLogCountSince(LocalDateTime.now().minusHours(24)));
        
        // Distribution statistics
        stats.setIncidentsBySeverity(incidentService.getIncidentStatsBySeverity());
        stats.setIncidentsByStatus(incidentService.getIncidentStatsByStatus());
        stats.setSystemsByVulnerability(systemService.getSystemStatsByVulnerability());
        stats.setThreatsByRiskLevel(threatService.getThreatStatsByRiskLevel());
        
        // Recent data
        stats.setRecentIncidents(incidentService.getRecentIncidents(5));
        stats.setRecentThreats(threatService.getRecentThreats(5));
        stats.setRecentActivities(logService.getRecentLogs(10));
        
        return stats;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getIncidentTrends(int days) {
        Map<String, Object> trends = new HashMap<>();
        
        LocalDateTime startDate = LocalDateTime.now().minusDays(days);
        
        // This would typically involve a more complex query
        // For now, we'll return basic stats
        trends.put("periodDays", days);
        trends.put("totalIncidents", incidentRepository.count());
        trends.put("openIncidents", incidentRepository.countOpenIncidents());
        trends.put("criticalIncidents", incidentRepository.countCriticalIncidents());
        
        return trends;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getThreatIntelligence() {
        Map<String, Object> intelligence = new HashMap<>();
        
        intelligence.put("activeThreats", threatRepository.countActiveThreats());
        intelligence.put("threatsByRisk", threatService.getThreatStatsByRiskLevel());
        intelligence.put("recentThreats", threatService.getRecentThreats(5));
        
        return intelligence;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getSystemHealth() {
        Map<String, Object> health = new HashMap<>();
        
        health.put("activeSystems", systemRepository.countActiveSystems());
        health.put("highRiskSystems", systemRepository.countHighRiskSystems());
        health.put("systemsByVulnerability", systemService.getSystemStatsByVulnerability());
        
        return health;
    }
}
