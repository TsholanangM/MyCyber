package com.cybersec.controller;

import com.cybersec.dto.ApiResponse;
import com.cybersec.dto.DashboardStatsDTO;
import com.cybersec.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard", description = "Dashboard and statistics APIs")
@SecurityRequirement(name = "bearerAuth")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/stats")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'USER')")
    @Operation(summary = "Get dashboard statistics", description = "Retrieve comprehensive dashboard statistics")
    public ResponseEntity<ApiResponse<DashboardStatsDTO>> getDashboardStats() {
        DashboardStatsDTO stats = dashboardService.getDashboardStats();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }

    @GetMapping("/incident-trends")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Get incident trends", description = "Retrieve incident trends over time")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getIncidentTrends(
            @RequestParam(defaultValue = "30") int days) {
        Map<String, Object> trends = dashboardService.getIncidentTrends(days);
        return ResponseEntity.ok(ApiResponse.success(trends));
    }

    @GetMapping("/threat-intelligence")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Get threat intelligence", description = "Retrieve threat intelligence data")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getThreatIntelligence() {
        Map<String, Object> intelligence = dashboardService.getThreatIntelligence();
        return ResponseEntity.ok(ApiResponse.success(intelligence));
    }

    @GetMapping("/system-health")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    @Operation(summary = "Get system health", description = "Retrieve system health metrics")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getSystemHealth() {
        Map<String, Object> health = dashboardService.getSystemHealth();
        return ResponseEntity.ok(ApiResponse.success(health));
    }
}
