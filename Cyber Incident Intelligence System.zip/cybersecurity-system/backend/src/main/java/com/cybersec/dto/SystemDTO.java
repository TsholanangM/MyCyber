package com.cybersec.dto;

import com.cybersec.enums.SystemStatus;
import com.cybersec.enums.SystemType;
import com.cybersec.enums.VulnerabilityLevel;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SystemDTO {
    
    private Long id;
    
    @NotBlank(message = "System name is required")
    private String systemName;
    
    @NotBlank(message = "Owner is required")
    private String owner;
    
    private String description;
    private String ipAddress;
    
    @NotNull(message = "Vulnerability level is required")
    private VulnerabilityLevel vulnerabilityLevel;
    
    @NotNull(message = "System type is required")
    private SystemType systemType;
    
    private SystemStatus status;
    private String location;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
