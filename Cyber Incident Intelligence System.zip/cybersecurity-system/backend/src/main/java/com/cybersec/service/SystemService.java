package com.cybersec.service;

import com.cybersec.dto.SystemDTO;
import com.cybersec.entity.System;
import com.cybersec.enums.SystemStatus;
import com.cybersec.enums.VulnerabilityLevel;
import com.cybersec.exception.ResourceNotFoundException;
import com.cybersec.repository.SystemRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class SystemService {

    private final SystemRepository systemRepository;
    private final LogService logService;

    @Transactional(readOnly = true)
    public List<SystemDTO> getAllSystems() {
        return systemRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Page<SystemDTO> getAllSystems(int page, int size, String sortBy, String direction) {
        Sort sort = direction.equalsIgnoreCase("desc") 
                ? Sort.by(sortBy).descending() 
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return systemRepository.findAll(pageable).map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public SystemDTO getSystemById(Long id) {
        System system = systemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("System", "id", id));
        return convertToDTO(system);
    }

    @Transactional
    public SystemDTO createSystem(SystemDTO systemDTO) {
        System system = new System();
        system.setSystemName(systemDTO.getSystemName());
        system.setOwner(systemDTO.getOwner());
        system.setDescription(systemDTO.getDescription());
        system.setIpAddress(systemDTO.getIpAddress());
        system.setVulnerabilityLevel(systemDTO.getVulnerabilityLevel());
        system.setSystemType(systemDTO.getSystemType());
        system.setStatus(SystemStatus.ACTIVE);
        system.setLocation(systemDTO.getLocation());

        System savedSystem = systemRepository.save(system);
        
        logService.logSystemAction("SYSTEM_CREATED", savedSystem.getId(), 
                "Created system: " + savedSystem.getSystemName());

        return convertToDTO(savedSystem);
    }

    @Transactional
    public SystemDTO updateSystem(Long id, SystemDTO systemDTO) {
        System system = systemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("System", "id", id));

        system.setSystemName(systemDTO.getSystemName());
        system.setOwner(systemDTO.getOwner());
        system.setDescription(systemDTO.getDescription());
        system.setIpAddress(systemDTO.getIpAddress());
        system.setVulnerabilityLevel(systemDTO.getVulnerabilityLevel());
        system.setSystemType(systemDTO.getSystemType());
        system.setLocation(systemDTO.getLocation());

        System updatedSystem = systemRepository.save(system);
        
        logService.logSystemAction("SYSTEM_UPDATED", updatedSystem.getId(), 
                "Updated system: " + updatedSystem.getSystemName());

        return convertToDTO(updatedSystem);
    }

    @Transactional
    public SystemDTO updateSystemStatus(Long id, SystemStatus status) {
        System system = systemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("System", "id", id));

        system.setStatus(status);

        System updatedSystem = systemRepository.save(system);
        
        logService.logSystemAction("STATUS_CHANGED", updatedSystem.getId(), 
                String.format("System status changed to %s: %s", status, updatedSystem.getSystemName()));

        return convertToDTO(updatedSystem);
    }

    @Transactional
    public void deleteSystem(Long id) {
        System system = systemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("System", "id", id));
        
        systemRepository.delete(system);
        
        logService.logSystemAction("SYSTEM_DELETED", id, 
                "Deleted system: " + system.getSystemName());
    }

    @Transactional(readOnly = true)
    public Page<SystemDTO> searchSystems(SystemStatus status, VulnerabilityLevel vulnerabilityLevel, 
                                          String search, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("systemName").ascending());
        return systemRepository.searchSystems(status, vulnerabilityLevel, search, pageable)
                .map(this::convertToDTO);
    }

    @Transactional(readOnly = true)
    public Map<String, Long> getSystemStatsByVulnerability() {
        List<Object[]> results = systemRepository.countByVulnerabilityLevel();
        return results.stream()
                .collect(Collectors.toMap(
                        row -> row[0].toString(),
                        row -> (Long) row[1]
                ));
    }

    private SystemDTO convertToDTO(System system) {
        SystemDTO dto = new SystemDTO();
        dto.setId(system.getId());
        dto.setSystemName(system.getSystemName());
        dto.setOwner(system.getOwner());
        dto.setDescription(system.getDescription());
        dto.setIpAddress(system.getIpAddress());
        dto.setVulnerabilityLevel(system.getVulnerabilityLevel());
        dto.setSystemType(system.getSystemType());
        dto.setStatus(system.getStatus());
        dto.setLocation(system.getLocation());
        dto.setCreatedAt(system.getCreatedAt());
        dto.setUpdatedAt(system.getUpdatedAt());
        return dto;
    }
}
