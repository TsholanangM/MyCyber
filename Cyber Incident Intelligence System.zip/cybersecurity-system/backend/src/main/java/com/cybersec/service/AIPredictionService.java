package com.cybersec.service;

import com.cybersec.dto.PredictionRequest;
import com.cybersec.dto.PredictionResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class AIPredictionService {

    @Value("${ai.service.url}")
    private String aiServiceUrl;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper;

    public PredictionResponse predictAttackLikelihood(Long systemId) {
        try {
            Map<String, Object> features = new HashMap<>();
            features.put("system_id", systemId);
            
            PredictionRequest request = new PredictionRequest();
            request.setPredictionType("ATTACK_LIKELIHOOD");
            request.setEntityType("SYSTEM");
            request.setEntityId(systemId);
            request.setFeatures(features);
            
            return callAIService(request);
        } catch (Exception e) {
            log.error("Error predicting attack likelihood: {}", e.getMessage());
            return createFallbackResponse("ATTACK_LIKELIHOOD", "SYSTEM", systemId);
        }
    }

    public PredictionResponse classifyIncidentSeverity(Long incidentId, Map<String, Object> features) {
        try {
            PredictionRequest request = new PredictionRequest();
            request.setPredictionType("SEVERITY_CLASSIFICATION");
            request.setEntityType("INCIDENT");
            request.setEntityId(incidentId);
            request.setFeatures(features);
            
            return callAIService(request);
        } catch (Exception e) {
            log.error("Error classifying incident severity: {}", e.getMessage());
            return createFallbackResponse("SEVERITY_CLASSIFICATION", "INCIDENT", incidentId);
        }
    }

    public PredictionResponse calculateRiskScore(Long systemId) {
        try {
            Map<String, Object> features = new HashMap<>();
            features.put("system_id", systemId);
            
            PredictionRequest request = new PredictionRequest();
            request.setPredictionType("RISK_SCORE");
            request.setEntityType("SYSTEM");
            request.setEntityId(systemId);
            request.setFeatures(features);
            
            return callAIService(request);
        } catch (Exception e) {
            log.error("Error calculating risk score: {}", e.getMessage());
            return createFallbackResponse("RISK_SCORE", "SYSTEM", systemId);
        }
    }

    public PredictionResponse detectAnomaly(Map<String, Object> metrics) {
        try {
            PredictionRequest request = new PredictionRequest();
            request.setPredictionType("ANOMALY_DETECTION");
            request.setEntityType("SYSTEM");
            request.setEntityId((Long) metrics.getOrDefault("system_id", 0L));
            request.setFeatures(metrics);
            
            return callAIService(request);
        } catch (Exception e) {
            log.error("Error detecting anomaly: {}", e.getMessage());
            return createFallbackResponse("ANOMALY_DETECTION", "SYSTEM", 0L);
        }
    }

    private PredictionResponse callAIService(PredictionRequest request) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            HttpEntity<PredictionRequest> entity = new HttpEntity<>(request, headers);
            
            ResponseEntity<String> response = restTemplate.exchange(
                    aiServiceUrl + "/predict",
                    HttpMethod.POST,
                    entity,
                    String.class
            );
            
            if (response.getStatusCode() == HttpStatus.OK) {
                JsonNode jsonResponse = objectMapper.readTree(response.getBody());
                
                return PredictionResponse.builder()
                        .predictionType(request.getPredictionType())
                        .entityType(request.getEntityType())
                        .entityId(request.getEntityId())
                        .predictionValue(jsonResponse.path("prediction").asText("UNKNOWN"))
                        .confidenceScore(jsonResponse.path("confidence").asDouble(0.0))
                        .modelVersion(jsonResponse.path("model_version").asText("1.0"))
                        .featuresUsed(request.getFeatures())
                        .additionalData(objectMapper.convertValue(jsonResponse.path("details"), Map.class))
                        .predictedAt(LocalDateTime.now())
                        .build();
            }
        } catch (Exception e) {
            log.error("AI service call failed: {}", e.getMessage());
        }
        
        return createFallbackResponse(request.getPredictionType(), request.getEntityType(), request.getEntityId());
    }

    private PredictionResponse createFallbackResponse(String predictionType, String entityType, Long entityId) {
        return PredictionResponse.builder()
                .predictionType(predictionType)
                .entityType(entityType)
                .entityId(entityId)
                .predictionValue("UNKNOWN")
                .confidenceScore(0.0)
                .modelVersion("fallback")
                .predictedAt(LocalDateTime.now())
                .build();
    }

    public Map<String, Object> getModelStatus() {
        try {
            ResponseEntity<String> response = restTemplate.getForEntity(
                    aiServiceUrl + "/status",
                    String.class
            );
            
            if (response.getStatusCode() == HttpStatus.OK) {
                return objectMapper.readValue(response.getBody(), Map.class);
            }
        } catch (Exception e) {
            log.error("Failed to get AI model status: {}", e.getMessage());
        }
        
        Map<String, Object> fallbackStatus = new HashMap<>();
        fallbackStatus.put("status", "UNAVAILABLE");
        fallbackStatus.put("message", "AI service is not reachable");
        return fallbackStatus;
    }
}
