package com.cybersec.enums;

public enum SystemType {
    SERVER,
    WORKSTATION,
    NETWORK_DEVICE,
    APPLICATION,
    DATABASE
}
