package com.cybersec.enums;

public enum EntityType {
    USER,
    INCIDENT,
    THREAT,
    SYSTEM,
    ATTACK_TYPE,
    SETTINGS
}
